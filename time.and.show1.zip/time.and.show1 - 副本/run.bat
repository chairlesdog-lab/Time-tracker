@echo off
REM 工作时间记录小程序启动脚本
REM 作者：小白开发者
REM 使用方法：双击此文件即可运行程序（不会显示黑色窗口）

echo 正在启动工作时间记录器...
start "" pythonw time_tracker.py
exit