"""
工作时间记录小程序
作者：小白开发者
版本：2.0
功能：记录每天的工作内容，帮助分析时间利用效率
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
from datetime import datetime
from typing import List, Dict, Optional, Callable
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# 导入matplotlib用于绘制扇形图
import matplotlib
matplotlib.use('TkAgg')  # 使用TkAgg后端
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

# 设置matplotlib中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 导入AI分析模块
from ai_analyzer import TimeAnalyzer


class ModernRoundedButton(tk.Canvas):
    """
    超酷的现代化圆角按钮类！
    用Canvas绘制，支持真正的大圆角、渐变色、阴影、悬停动画效果
    """
    
    def __init__(self, parent, text: str, command: Callable, 
                 bg_color: str, hover_color: str, text_color: str = "white",
                 width: int = 160, height: int = 50, corner_radius: int = 25,
                 font_size: int = 12, **kwargs):
        """
        初始化现代化圆角按钮
        
        参数说明：
        parent: 父容器
        text: 按钮上显示的文字
        command: 点击按钮时执行的函数
        bg_color: 按钮正常状态的背景色
        hover_color: 鼠标悬停时的背景色
        text_color: 文字颜色
        width: 按钮宽度
        height: 按钮高度
        corner_radius: 圆角半径（越大越圆）
        font_size: 字体大小
        """
        # 计算Canvas实际大小（要留一点空间画阴影）
        canvas_width = width + 8
        canvas_height = height + 8
        
        super().__init__(parent, width=canvas_width, height=canvas_height, 
                        highlightthickness=0, bg="#F5F7FA", **kwargs)
        
        self.command = command
        self.bg_color = bg_color
        self.hover_color = hover_color
        self.current_color = bg_color
        self.width = width
        self.height = height
        self.corner_radius = corner_radius
        
        # 按钮在Canvas中的位置（居中，留阴影空间）
        self.x1 = 4
        self.y1 = 4
        self.x2 = self.x1 + width
        self.y2 = self.y1 + height
        
        # 先绘制初始按钮
        self._draw_button()
        
        # 然后绘制文字
        self.text_id = self.create_text(
            canvas_width // 2, canvas_height // 2,
            text=text,
            fill=text_color,
            font=('微软雅黑', font_size, 'bold')
        )
        
        # 最后确保文字在最上层
        self.tag_raise(self.text_id)
        
        # 绑定鼠标事件
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)
        self.bind("<ButtonRelease-1>", self._on_release)
        
        self.is_pressed = False
    
    def _draw_round_rect(self, x1: int, y1: int, x2: int, y2: int, 
                        radius: int, color: str, shadow: bool = True):
        """
        绘制圆角矩形（内部辅助方法）
        这是Canvas画圆角的经典方法：用圆和矩形拼接
        """
        # 先画阴影（如果需要）
        if shadow:
            shadow_offset = 3
            self.create_rounded_rectangle(
                x1 + shadow_offset, y1 + shadow_offset,
                x2 + shadow_offset, y2 + shadow_offset,
                radius=radius,
                fill="#D0D0D0",  # 浅灰色阴影
                outline=""
            )
        
        # 再画主按钮
        self.create_rounded_rectangle(
            x1, y1, x2, y2,
            radius=radius,
            fill=color,
            outline=""
        )
    
    def create_rounded_rectangle(self, x1: int, y1: int, x2: int, y2: int, 
                                radius: int, **kwargs):
        """
        Canvas没有直接的圆角矩形方法，这是一个自定义实现
        通过画四个圆和一个矩形来组成圆角矩形
        """
        points = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1
        ]
        return self.create_polygon(points, smooth=True, **kwargs)
    
    def _draw_button(self):
        """
        绘制整个按钮
        """
        self.delete("button_bg")
        self._draw_round_rect(
            self.x1, self.y1, self.x2, self.y2,
            self.corner_radius,
            self.current_color,
            shadow=True
        )
        # 确保文字在最上层！这是关键！
        # 只有当text_id已经创建时才调用tag_raise
        if hasattr(self, 'text_id'):
            self.tag_raise(self.text_id)
    
    def _on_enter(self, event):
        """
        鼠标进入按钮区域：改变颜色为悬停色
        """
        self.current_color = self.hover_color
        self._draw_button()
        self.config(cursor="hand2")  # 鼠标变成手型
    
    def _on_leave(self, event):
        """
        鼠标离开按钮区域：恢复正常颜色
        """
        self.current_color = self.bg_color
        self._draw_button()
        self.config(cursor="")
    
    def _on_click(self, event):
        """
        鼠标按下按钮：稍微缩小一点，有按压感
        """
        self.is_pressed = True
        # 稍微移动一下，产生按压效果
        self.x1 += 1
        self.y1 += 1
        self.x2 += 1
        self.y2 += 1
        self._draw_button()
        # 文字也要跟着动
        self.move(self.text_id, 1, 1)
    
    def _on_release(self, event):
        """
        鼠标松开按钮：恢复大小并执行命令
        """
        if self.is_pressed:
            # 恢复位置
            self.x1 -= 1
            self.y1 -= 1
            self.x2 -= 1
            self.y2 -= 1
            self._draw_button()
            self.move(self.text_id, -1, -1)
            
            # 执行命令
            if self.command:
                self.command()
            
            self.is_pressed = False


class ModernTimeEntry(tk.Frame):
    """
    超酷的现代化时间输入框组件！
    支持圆角、渐变色、悬停和聚焦动画效果
    """
    
    def __init__(self, parent, text_variable, width=60, height=50, font_size=18, **kwargs):
        """
        初始化现代化时间输入框
        
        参数说明：
        parent: 父容器
        text_variable: 绑定的StringVar变量
        width: 输入框宽度
        height: 输入框高度
        font_size: 字体大小
        """
        super().__init__(parent, bg="#FFFFFF", **kwargs)
        
        self.width = width
        self.height = height
        self.is_focused = False
        
        # 配色方案
        self.normal_bg = "#F8FAFC"  # 淡灰色背景
        self.hover_bg = "#F1F5F9"   # 悬停背景
        self.focus_bg = "#EFF6FF"    # 聚焦背景
        self.normal_border = "#E2E8F0"  # 普通边框
        self.hover_border = "#CBD5E1"   # 悬停边框
        self.focus_border = "#3B82F6"   # 聚焦边框（蓝色）
        
        # 创建Canvas用于绘制圆角背景
        self.canvas = tk.Canvas(
            self,
            width=width,
            height=height,
            bg="#FFFFFF",
            highlightthickness=0
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # 绘制初始状态
        self.current_bg = self.normal_bg
        self.current_border = self.normal_border
        self._draw_background()
        
        # 创建实际的输入框（放在Canvas上面）
        self.entry = tk.Entry(
            self.canvas,
            textvariable=text_variable,
            font=('微软雅黑', font_size, 'bold'),
            justify=tk.CENTER,
            bg=self.normal_bg,
            fg="#1E293B",
            bd=0,
            highlightthickness=0,
            relief=tk.FLAT,
            insertbackground="#3B82F6"  # 光标颜色（蓝色）
        )
        
        # 计算输入框位置（居中）
        entry_x = 10
        entry_y = 8
        entry_width = width - 20
        entry_height = height - 16
        
        self.canvas.create_window(
            width // 2, height // 2,
            window=self.entry,
            width=entry_width,
            height=entry_height
        )
        
        # 绑定事件
        self.entry.bind("<FocusIn>", self._on_focus_in)
        self.entry.bind("<FocusOut>", self._on_focus_out)
        self.canvas.bind("<Enter>", self._on_enter)
        self.canvas.bind("<Leave>", self._on_leave)
        # 让Canvas点击时也能聚焦到输入框
        self.canvas.bind("<Button-1>", lambda e: self.entry.focus_set())
    
    def _draw_background(self):
        """
        绘制圆角背景
        """
        self.canvas.delete("bg")
        
        # 绘制外边框
        self._create_rounded_rectangle(
            1, 1, self.width - 1, self.height - 1,
            radius=12,
            fill=self.current_bg,
            outline=self.current_border,
            width=2
        )
    
    def _create_rounded_rectangle(self, x1, y1, x2, y2, radius, **kwargs):
        """
        绘制圆角矩形的辅助方法
        """
        points = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1
        ]
        return self.canvas.create_polygon(points, smooth=True, tags="bg", **kwargs)
    
    def _on_enter(self, event):
        """
        鼠标进入时：改变背景色
        """
        if not self.is_focused:
            self.current_bg = self.hover_bg
            self.current_border = self.hover_border
            self._draw_background()
            self.entry.config(bg=self.hover_bg)
    
    def _on_leave(self, event):
        """
        鼠标离开时：恢复背景色
        """
        if not self.is_focused:
            self.current_bg = self.normal_bg
            self.current_border = self.normal_border
            self._draw_background()
            self.entry.config(bg=self.normal_bg)
    
    def _on_focus_in(self, event):
        """
        获得焦点时：蓝色边框
        """
        self.is_focused = True
        self.current_bg = self.focus_bg
        self.current_border = self.focus_border
        self._draw_background()
        self.entry.config(bg=self.focus_bg)
    
    def _on_focus_out(self, event):
        """
        失去焦点时：恢复原状
        """
        self.is_focused = False
        self.current_bg = self.normal_bg
        self.current_border = self.normal_border
        self._draw_background()
        self.entry.config(bg=self.normal_bg)


class ModernCombobox(tk.Frame):
    """
    超酷的现代化下拉选择框组件！
    支持圆角、渐变色、悬停和聚焦动画效果
    """
    
    def __init__(self, parent, text_variable, values, width=180, height=50, font_size=14, **kwargs):
        """
        初始化现代化下拉选择框
        
        参数说明：
        parent: 父容器
        text_variable: 绑定的StringVar变量
        values: 选项列表
        width: 选择框宽度
        height: 选择框高度
        font_size: 字体大小
        """
        super().__init__(parent, bg="#FFFFFF", **kwargs)
        
        self.width = width
        self.height = height
        self.values = values
        self.is_focused = False
        self.is_open = False
        
        # 配色方案
        self.normal_bg = "#F8FAFC"  # 淡灰色背景
        self.hover_bg = "#F1F5F9"   # 悬停背景
        self.focus_bg = "#EFF6FF"    # 聚焦背景
        self.normal_border = "#E2E8F0"  # 普通边框
        self.hover_border = "#CBD5E1"   # 悬停边框
        self.focus_border = "#3B82F6"   # 聚焦边框（蓝色）
        
        # 创建Canvas用于绘制圆角背景
        self.canvas = tk.Canvas(
            self,
            width=width,
            height=height,
            bg="#FFFFFF",
            highlightthickness=0
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # 绘制初始状态
        self.current_bg = self.normal_bg
        self.current_border = self.normal_border
        self._draw_background()
        
        # 创建实际的输入框（只读模式）
        self.entry = tk.Entry(
            self.canvas,
            textvariable=text_variable,
            font=('微软雅黑', font_size, 'bold'),
            justify=tk.CENTER,
            bg=self.normal_bg,
            fg="#1E293B",
            bd=0,
            highlightthickness=0,
            relief=tk.FLAT,
            state='readonly',  # 只读，通过下拉选择
            readonlybackground=self.normal_bg
        )
        
        # 计算输入框位置
        entry_width = width - 50  # 留出箭头按钮的空间
        entry_height = height - 16
        
        self.canvas.create_window(
            (width - 40) // 2, height // 2,
            window=self.entry,
            width=entry_width,
            height=entry_height
        )
        
        # 绘制下拉箭头按钮
        self._draw_arrow()
        
        # 绑定事件
        self.canvas.bind("<Enter>", self._on_enter)
        self.canvas.bind("<Leave>", self._on_leave)
        self.canvas.bind("<Button-1>", self._on_click)
        self.entry.bind("<FocusIn>", self._on_focus_in)
        self.entry.bind("<FocusOut>", self._on_focus_out)
        
        # 存储变量引用
        self.text_variable = text_variable
    
    def _draw_background(self):
        """
        绘制圆角背景
        """
        self.canvas.delete("bg")
        
        # 绘制外边框
        self._create_rounded_rectangle(
            1, 1, self.width - 1, self.height - 1,
            radius=12,
            fill=self.current_bg,
            outline=self.current_border,
            width=2
        )
    
    def _create_rounded_rectangle(self, x1, y1, x2, y2, radius, **kwargs):
        """
        绘制圆角矩形的辅助方法
        """
        points = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1
        ]
        return self.canvas.create_polygon(points, smooth=True, tags="bg", **kwargs)
    
    def _draw_arrow(self):
        """
        绘制下拉箭头
        """
        self.canvas.delete("arrow")
        
        # 箭头位置（右侧）
        arrow_x = self.width - 25
        arrow_y = self.height // 2
        
        # 绘制三角形箭头
        arrow_size = 8
        if self.is_open:
            # 向上箭头
            points = [
                arrow_x - arrow_size, arrow_y + arrow_size // 2,
                arrow_x + arrow_size, arrow_y + arrow_size // 2,
                arrow_x, arrow_y - arrow_size // 2
            ]
        else:
            # 向下箭头
            points = [
                arrow_x - arrow_size, arrow_y - arrow_size // 2,
                arrow_x + arrow_size, arrow_y - arrow_size // 2,
                arrow_x, arrow_y + arrow_size // 2
            ]
        
        self.canvas.create_polygon(
            points,
            fill="#6B7280",
            outline="",
            tags="arrow"
        )
    
    def _on_enter(self, event):
        """
        鼠标进入时：改变背景色
        """
        if not self.is_focused:
            self.current_bg = self.hover_bg
            self.current_border = self.hover_border
            self._draw_background()
            self._draw_arrow()
            self.entry.config(readonlybackground=self.hover_bg)
    
    def _on_leave(self, event):
        """
        鼠标离开时：恢复背景色
        """
        if not self.is_focused:
            self.current_bg = self.normal_bg
            self.current_border = self.normal_border
            self._draw_background()
            self._draw_arrow()
            self.entry.config(readonlybackground=self.normal_bg)
    
    def _on_focus_in(self, event):
        """
        获得焦点时：蓝色边框
        """
        self.is_focused = True
        self.current_bg = self.focus_bg
        self.current_border = self.focus_border
        self._draw_background()
        self._draw_arrow()
        self.entry.config(readonlybackground=self.focus_bg)
    
    def _on_focus_out(self, event):
        """
        失去焦点时：恢复原状
        """
        self.is_focused = False
        self.current_bg = self.normal_bg
        self.current_border = self.normal_border
        self._draw_background()
        self._draw_arrow()
        self.entry.config(readonlybackground=self.normal_bg)
    
    def _on_click(self, event):
        """
        点击时显示下拉菜单
        """
        self.is_open = True
        self._draw_arrow()
        self._show_dropdown()
    
    def _show_dropdown(self):
        """
        显示下拉选择菜单
        """
        # 创建下拉窗口
        self.dropdown = tk.Toplevel(self)
        self.dropdown.overrideredirect(True)  # 无边框窗口
        self.dropdown.config(bg="#FFFFFF")
        
        # 计算下拉窗口位置
        x = self.winfo_rootx()
        y = self.winfo_rooty() + self.height + 2
        
        # 设置下拉窗口大小和位置
        dropdown_width = self.width
        # 计算所需高度：每个选项30像素
        needed_height = len(self.values) * 30 + 10
        # 最大高度设为150，显示约5个选项，超出部分使用滚动条
        dropdown_height = min(needed_height, 150)
        
        self.dropdown.geometry(f"{dropdown_width}x{dropdown_height}+{x}+{y}")
        
        # 创建带滚动条的列表框
        frame = tk.Frame(self.dropdown, bg="#FFFFFF")
        frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建滚动条（先创建，确保它在Canvas旁边）
        scrollbar = ttk.Scrollbar(frame, orient="vertical")
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 创建Canvas用于绘制圆角效果
        canvas = tk.Canvas(frame, bg="#FFFFFF", highlightthickness=0, 
                          yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=canvas.yview)
        
        # 创建内部Frame放置选项
        options_frame = tk.Frame(canvas, bg="#FFFFFF")
        canvas_window = canvas.create_window((0, 0), window=options_frame, anchor="nw", 
                                            width=dropdown_width-25)
        
        # 绑定滚动
        def on_frame_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            # 如果内容高度超过Canvas高度，启用滚动条
            bbox = canvas.bbox("all")
            if bbox:
                content_height = bbox[3] - bbox[1]
                canvas_height = canvas.winfo_height()
                if content_height > canvas_height:
                    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                else:
                    scrollbar.pack_forget()
        
        options_frame.bind("<Configure>", on_frame_configure)
        canvas.bind("<Configure>", on_frame_configure)
        
        # 绑定鼠标滚轮事件到Canvas和选项
        def on_dropdown_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            return "break"
        
        canvas.bind("<MouseWheel>", on_dropdown_mousewheel)
        options_frame.bind("<MouseWheel>", on_dropdown_mousewheel)
        
        # 创建选项按钮
        for i, value in enumerate(self.values):
            option_btn = tk.Label(
                options_frame,
                text=value,
                font=('微软雅黑', 11),
                bg="#FFFFFF",
                fg="#374151",
                padx=10,
                pady=4,
                anchor="w",
                cursor="hand2"
            )
            option_btn.pack(fill=tk.X, padx=2, pady=0)
            
            # 绑定悬停效果
            def on_option_enter(e, btn=option_btn):
                btn.config(bg="#EFF6FF", fg="#3B82F6")
            def on_option_leave(e, btn=option_btn):
                btn.config(bg="#FFFFFF", fg="#374151")
            def on_option_click(e, val=value):
                self.text_variable.set(val)
                self._close_dropdown()
            
            option_btn.bind("<Enter>", on_option_enter)
            option_btn.bind("<Leave>", on_option_leave)
            option_btn.bind("<Button-1>", on_option_click)
            # 为每个选项按钮绑定鼠标滚轮
            option_btn.bind("<MouseWheel>", on_dropdown_mousewheel)
        
        # 绑定点击外部关闭
        self.dropdown.bind("<FocusOut>", lambda e: self._close_dropdown())
        self.dropdown.focus_set()
        
        # 绑定主窗口点击关闭
        self.bind_all("<Button-1>", self._on_global_click, add="+")
    
    def _close_dropdown(self):
        """
        关闭下拉菜单
        """
        self.is_open = False
        self._draw_arrow()
        if hasattr(self, 'dropdown'):
            self.dropdown.destroy()
            delattr(self, 'dropdown')
        # 解除全局点击绑定
        self.unbind_all("<Button-1>")
    
    def _on_global_click(self, event):
        """
        全局点击事件处理
        """
        if hasattr(self, 'dropdown'):
            # 检查点击是否在下拉菜单外部
            x, y = event.x_root, event.y_root
            dropdown_x = self.dropdown.winfo_rootx()
            dropdown_y = self.dropdown.winfo_rooty()
            dropdown_w = self.dropdown.winfo_width()
            dropdown_h = self.dropdown.winfo_height()
            
            if not (dropdown_x <= x <= dropdown_x + dropdown_w and 
                    dropdown_y <= y <= dropdown_y + dropdown_h):
                self._close_dropdown()


# 数据存储文件名
DATA_FILE = "time_records.json"
# 窗口设置存储文件名
WINDOW_SETTINGS_FILE = "window_settings.json"
# AI分析结果存储文件名
AI_RESULT_FILE = "ai_analysis_result.json"

class TimeRecord:
    """
    一条时间记录，包含起始时间、结束时间、活动类型和事项内容
    用于记录工作的开始和结束时间，并计算时长
    """
    def __init__(self, year: int, month: int, day: int, start_hour: int, start_minute: int, 
                 end_hour: int = None, end_minute: int = None, activity_type: str = "工作", content: str = "",
                 end_year: int = None, end_month: int = None, end_day: int = None):
        """
        初始化一条时间记录
        
        参数说明：
        year: 年份，比如2026
        month: 月份，1-12
        day: 日期，1-31
        start_hour: 开始小时，0-23
        start_minute: 开始分钟，0-59
        end_hour: 结束小时，0-23（可选）
        end_minute: 结束分钟，0-59（可选）
        activity_type: 活动类型，比如"工作"、"聊天"、"饮食"、"午休"、"娱乐"
        content: 工作内容，比如"编写代码"或"开会讨论"
        end_year: 结束年份（可选，默认与起始日期相同）
        end_month: 结束月份（可选，默认与起始日期相同）
        end_day: 结束日期（可选，默认与起始日期相同）
        """
        self.year = year
        self.month = month
        self.day = day
        self.start_hour = start_hour
        self.start_minute = start_minute
        self.end_hour = end_hour if end_hour is not None else start_hour
        self.end_minute = end_minute if end_minute is not None else start_minute
        # 结束日期默认为起始日期
        self.end_year = end_year if end_year is not None else year
        self.end_month = end_month if end_month is not None else month
        self.end_day = end_day if end_day is not None else day
        self.activity_type = activity_type
        self.content = content
        # 生成一个唯一ID，用于识别这条记录
        self.id = f"{year:04d}{month:02d}{day:02d}{start_hour:02d}{start_minute:02d}"
    
    def to_dict(self) -> Dict:
        """
        将记录转换成字典格式，方便保存到JSON文件
        """
        return {
            "id": self.id,
            "year": self.year,
            "month": self.month,
            "day": self.day,
            "start_hour": self.start_hour,
            "start_minute": self.start_minute,
            "end_hour": self.end_hour,
            "end_minute": self.end_minute,
            "end_year": self.end_year,
            "end_month": self.end_month,
            "end_day": self.end_day,
            "activity_type": self.activity_type,
            "content": self.content
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'TimeRecord':
        """
        从字典创建TimeRecord对象
        支持旧版本数据（没有结束时间字段和活动类型）
        """
        if "hour" in data and "minute" in data:
            start_hour = data["hour"]
            start_minute = data["minute"]
            end_hour = data.get("end_hour", data["hour"])
            end_minute = data.get("end_minute", data["minute"])
        else:
            start_hour = data["start_hour"]
            start_minute = data["start_minute"]
            end_hour = data.get("end_hour", start_hour)
            end_minute = data.get("end_minute", start_minute)
        
        # 获取结束日期（兼容旧数据，默认为起始日期）
        end_year = data.get("end_year", data["year"])
        end_month = data.get("end_month", data["month"])
        end_day = data.get("end_day", data["day"])
            
        return cls(
            year=data["year"],
            month=data["month"],
            day=data["day"],
            start_hour=start_hour,
            start_minute=start_minute,
            end_hour=end_hour,
            end_minute=end_minute,
            activity_type=data.get("activity_type", "工作"),
            content=data["content"],
            end_year=end_year,
            end_month=end_month,
            end_day=end_day
        )
    
    def get_start_datetime_str(self) -> str:
        """
        获取格式化的起始日期时间字符串
        """
        return f"{self.year:04d}-{self.month:02d}-{self.day:02d} {self.start_hour:02d}:{self.start_minute:02d}"
    
    def get_end_datetime_str(self) -> str:
        """
        获取格式化的结束日期时间字符串
        """
        return f"{self.end_year:04d}-{self.end_month:02d}-{self.end_day:02d} {self.end_hour:02d}:{self.end_minute:02d}"
    
    def get_duration_minutes(self) -> int:
        """
        计算时长（分钟）
        支持跨天计算
        """
        from datetime import datetime
        
        start_dt = datetime(self.year, self.month, self.day, self.start_hour, self.start_minute)
        end_dt = datetime(self.end_year, self.end_month, self.end_day, self.end_hour, self.end_minute)
        
        # 计算时间差（分钟）
        duration = (end_dt - start_dt).total_seconds() / 60
        return int(duration)
    
    def get_duration_str(self) -> str:
        """
        获取格式化的时长字符串
        """
        total_minutes = self.get_duration_minutes()
        hours = total_minutes // 60
        minutes = total_minutes % 60
        
        if hours > 0:
            return f"{hours}小时{minutes}分钟"
        else:
            return f"{minutes}分钟"
    
    def __str__(self) -> str:
        """
        返回记录的字符串表示
        """
        duration_str = self.get_duration_str()
        return f"{self.get_start_datetime_str()} - {self.get_end_datetime_str()} ({duration_str}) - {self.content}"



class TimeTrackerApp:
    """
    时间记录应用程序的主类
    """
    def __init__(self, root: tk.Tk):
        """
        初始化应用程序
        """
        self.root = root
        self.root.title("工作时间记录器")
        
        # 存储所有时间记录的列表
        self.records: List[TimeRecord] = []
        
        # 跟踪当前正在编辑的记录ID（None表示新增模式）
        self.editing_record_id: Optional[str] = None
        
        # 加载上次的窗口大小设置（如果存在）
        self.load_window_settings()
        
        # 加载之前保存的记录
        self.load_records()
        
        # 设置界面
        self.setup_ui()
        
        # 绑定窗口关闭事件，保存窗口大小
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        
        # 刷新记录列表显示
        self.refresh_record_list()
    
    def load_window_settings(self):
        """
        加载上次保存的窗口大小设置
        """
        if os.path.exists(WINDOW_SETTINGS_FILE):
            try:
                with open(WINDOW_SETTINGS_FILE, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                    width = settings.get('width', 1000)
                    height = settings.get('height', 900)
                    x = settings.get('x')
                    y = settings.get('y')
                    
                    if x is not None and y is not None:
                        self.root.geometry(f"{width}x{height}+{x}+{y}")
                    else:
                        self.root.geometry(f"{width}x{height}")
            except:
                self.root.geometry("1000x900")
        else:
            self.root.geometry("1000x900")
    
    def save_window_settings(self):
        """
        保存当前窗口大小和位置
        """
        try:
            # 获取窗口大小和位置
            geometry = self.root.geometry()
            # geometry格式: "宽x高+x+y"
            size_part, pos_part = geometry.split('+', 1)
            width, height = map(int, size_part.split('x'))
            x, y = map(int, pos_part.split('+'))
            
            settings = {
                'width': width,
                'height': height,
                'x': x,
                'y': y
            }
            
            with open(WINDOW_SETTINGS_FILE, 'w', encoding='utf-8') as f:
                json.dump(settings, f, ensure_ascii=False, indent=2)
        except:
            pass
    
    def on_close(self):
        """
        窗口关闭时的处理
        """
        self.save_window_settings()
        self.root.destroy()
    
    def setup_ui(self):
        """
        设置用户界面（现代化版本，支持窗口缩放，带页签功能）
        """
        # 设置窗口背景色（使用新的柔和背景）
        self.root.configure(bg="#F5F7FA")
        
        # 设置最小窗口大小，确保所有内容都能显示
        self.root.minsize(width=800, height=600)
        
        # 创建Notebook页签控件
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 配置Notebook样式
        style = ttk.Style()
        style.configure('TNotebook', background='#F5F7FA', tabmargins=[2, 5, 2, 0])
        style.configure('TNotebook.Tab', 
                       font=('微软雅黑', 12, 'bold'),
                       padding=[20, 10],
                       background='#E2E8F0')
        style.map('TNotebook.Tab',
                 background=[('selected', '#5B8DEE')],
                 foreground=[('selected', '#FFFFFF'), ('!selected', '#374151')])
        
        # ========== 第一个页签：记录 ==========
        self.record_tab = tk.Frame(self.notebook, bg="#F5F7FA")
        self.notebook.add(self.record_tab, text="📝 记录")
        
        # 创建全局滚动容器 - 确保窗口缩小时内容可滚动
        # 步骤1：创建一个Canvas用于滚动
        scroll_canvas = tk.Canvas(self.record_tab, bg="#F5F7FA", highlightthickness=0)
        scroll_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 步骤2：创建垂直滚动条
        scrollbar = ttk.Scrollbar(self.record_tab, orient="vertical", command=scroll_canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 步骤3：配置Canvas
        scroll_canvas.configure(yscrollcommand=scrollbar.set)
        
        # 步骤4：创建内部Frame来放置所有内容
        main_container = tk.Frame(scroll_canvas, bg="#F5F7FA")
        canvas_window = scroll_canvas.create_window((0, 0), window=main_container, anchor="nw")
        
        # 当Canvas大小变化时，更新内部Frame的宽度以匹配
        def _on_canvas_configure(event):
            scroll_canvas.itemconfig(canvas_window, width=event.width)
            scroll_canvas.configure(scrollregion=scroll_canvas.bbox("all"))
        
        scroll_canvas.bind('<Configure>', _on_canvas_configure)
        
        # 当内部Frame大小变化时，更新scrollregion
        def _on_frame_configure(event):
            scroll_canvas.configure(scrollregion=scroll_canvas.bbox("all"))
        
        main_container.bind("<Configure>", _on_frame_configure)
        
        # 绑定鼠标滚轮事件，支持在程序任何位置滚动
        def _on_mousewheel(event):
            # 获取当前活动的页签
            current_tab = self.notebook.index(self.notebook.select())
            # 0是记录页签，只有记录页签需要处理滚动
            if current_tab != 0:
                return
            
            # 获取鼠标位置下的组件
            try:
                widget_under_mouse = self.root.winfo_containing(event.x_root, event.y_root)
            except:
                widget_under_mouse = None
            
            # 如果鼠标在文本输入框或多行文本框上，让输入框自己处理滚动
            if widget_under_mouse:
                # 检查是否是输入框类型组件
                if isinstance(widget_under_mouse, (tk.Entry, tk.Text)):
                    return
                # 检查父级是否是文本框（处理Text的滚动条等情况）
                parent = widget_under_mouse.winfo_parent()
                if parent:
                    try:
                        parent_widget = widget_under_mouse.nametowidget(parent)
                        if isinstance(parent_widget, tk.Text):
                            return
                    except:
                        pass
            
            # 滚动Canvas
            scroll_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            return "break"  # 阻止事件继续传播
        
        # 绑定到主窗口，实现全局滚动
        self.root.bind("<MouseWheel>", _on_mousewheel, add="+")
        
        # 为所有子组件也绑定滚轮事件，确保点击后也能滚动
        def bind_mousewheel_to_children(widget):
            """递归为所有子组件绑定鼠标滚轮事件"""
            for child in widget.winfo_children():
                # 跳过Canvas和滚动条本身，避免冲突
                if not isinstance(child, (tk.Canvas, ttk.Scrollbar)):
                    child.bind("<MouseWheel>", _on_mousewheel, add="+")
                # 递归处理子组件
                bind_mousewheel_to_children(child)
        
        # 为主容器及其所有子组件绑定滚轮事件
        bind_mousewheel_to_children(main_container)
        
        # 现代化配色方案（降低饱和度，更柔和）
        self.colors = {
            "primary": "#5B8DEE",  # 更柔和的蓝色
            "success": "#66BB6A",  # 更柔和的绿色
            "warning": "#FFB74D",  # 更柔和的橙色
            "danger": "#EF5350",  # 更柔和的红色
            "info": "#42A5F5",
            "light": "#FAFAFA",
            "dark": "#333333",
            "background": "#F5F7FA",  # 更柔和的背景色
            "card": "#FFFFFF"
        }

        # 设置ttk样式，实现圆润多彩的按钮
        style = ttk.Style()
        # 使用clam主题，它支持圆角边框
        style.theme_use('clam')
        

        
        # 为不同颜色的按钮创建样式变体（使用更柔和的配色）
        # 绿色按钮 - 保存记录
        style.configure('RoundedGreen.TButton',
                        font=('微软雅黑', 11, 'bold'),
                        foreground='white',
                        background='#66BB6A',
                        borderwidth=0,
                        focusthickness=0,
                        focuscolor='',
                        padding=18,
                        relief='flat', borderradius=25)
        style.map('RoundedGreen.TButton',
                  background=[('active', '#4CAF50')],
                  foreground=[('active', 'white'), ('pressed', 'white')])
        
        # 橙色按钮 - 清除内容
        style.configure('RoundedOrange.TButton',
                        font=('微软雅黑', 11, 'bold'),
                        foreground='white',
                        background='#FFB74D',
                        borderwidth=0,
                        focusthickness=0,
                        focuscolor='',
                        padding=18,
                        relief='flat',
                        borderradius=25)
        style.map('RoundedOrange.TButton',
                  background=[('active', '#FF9800')],
                  foreground=[('active', 'white'), ('pressed', 'white')])
        
        # 红色按钮 - 删除选中
        style.configure('RoundedRed.TButton',
                        font=('微软雅黑', 11, 'bold'),
                        foreground='white',
                        background='#EF5350',
                        borderwidth=0,
                        focusthickness=0,
                        focuscolor='',
                        padding=18,
                        relief='flat', borderradius=25)
        style.map('RoundedRed.TButton',
                  background=[('active', '#E53935')],
                  foreground=[('active', 'white'), ('pressed', 'white')])
        
        # 蓝色按钮 - 导出Excel
        style.configure('RoundedBlue.TButton',
                        font=('微软雅黑', 11, 'bold'),
                        foreground='white',
                        background='#42A5F5',
                        borderwidth=0,
                        focusthickness=0,
                        focuscolor='',
                        padding=18,
                        relief='flat', borderradius=25)
        style.map('RoundedBlue.TButton',
                  background=[('active', '#1E88E5')],
                  foreground=[('active', 'white'), ('pressed', 'white')])

        # ========== 第二个页签：统计 ==========
        self.setup_statistics_tab()
        
        # ========== 第三个页签：AI分析 ==========
        self.setup_ai_analysis_tab()

        # 第一部分：标题卡片
        title_card = tk.Frame(main_container, bg=self.colors["primary"], padx=20, pady=15)
        title_card.pack(fill=tk.X, padx=15, pady=(15, 10))
        
        # 添加卡片阴影效果
        title_card.config(highlightbackground="#cccccc", highlightcolor="#999999", highlightthickness=2)
        
        tk.Label(
            title_card, 
            text="⏰ 工作时间记录器", 
            font=("微软雅黑", 18, "bold"), 
            fg="white", 
            bg=self.colors["primary"]
        ).pack(side=tk.LEFT)
        
        # 第二部分：时间输入区域（卡片式设计）
        time_card = tk.Frame(main_container, bg=self.colors["card"], padx=20, pady=10)
        time_card.pack(fill=tk.X, padx=15, pady=(0, 10))
        # 添加卡片阴影效果
        time_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        # 时间信息标题和状态提示
        title_frame = tk.Frame(time_card, bg=self.colors["card"])
        title_frame.pack(fill=tk.X, anchor=tk.W)
        
        time_title = tk.Label(title_frame, text="🕐 时间信息", font=("微软雅黑", 12, "bold"), fg=self.colors["dark"], bg=self.colors["card"])
        time_title.pack(side=tk.LEFT)
        
        # 状态提示标签
        self.status_label = tk.Label(title_frame, text=" [新增模式]", font=("微软雅黑", 10), fg="#999999", bg=self.colors["card"])
        self.status_label.pack(side=tk.LEFT, padx=5)
        
        # 时间输入容器 - 水平排列
        time_inputs_frame = tk.Frame(time_card, bg=self.colors["card"])
        time_inputs_frame.pack(fill=tk.X, pady=(10, 0))
        
        # 起始时间容器 - 超酷现代化设计！
        start_frame = tk.Frame(time_inputs_frame, bg=self.colors["card"])
        start_frame.pack(side=tk.LEFT)
        
        tk.Label(
            start_frame, 
            text="🚀 起始时间", 
            font=("微软雅黑", 11, 'bold'), 
            fg="#374151", 
            bg=self.colors["card"]
        ).pack(anchor=tk.W)
        
        # 起始日期选择 - 现代化卡片式设计
        start_date_frame = tk.Frame(start_frame, bg=self.colors["card"])
        start_date_frame.pack(anchor=tk.W, pady=(8, 0))
        
        current_date = datetime.now()
        self.start_year_var = tk.StringVar(value=str(current_date.year))
        self.start_month_var = tk.StringVar(value=str(current_date.month))
        self.start_day_var = tk.StringVar(value=str(current_date.day))
        
        # 日期选择容器 - 圆角卡片效果
        start_date_card = tk.Frame(start_date_frame, bg="#F3F4F6", padx=12, pady=8)
        start_date_card.pack(side=tk.LEFT)
        start_date_card.config(highlightbackground="#E5E7EB", highlightcolor="#5B8DEE", highlightthickness=1)
        
        # 📅 日期图标
        tk.Label(start_date_card, text="📅", font=("微软雅黑", 12), bg="#F3F4F6").pack(side=tk.LEFT, padx=(0, 8))
        
        # 年输入框 - 现代化样式
        year_entry = tk.Entry(
            start_date_card, 
            textvariable=self.start_year_var, 
            font=("微软雅黑", 11, "bold"), 
            width=5, 
            justify="center",
            bg="white",
            fg="#1F2937",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#D1D5DB",
            highlightcolor="#5B8DEE"
        )
        year_entry.pack(side=tk.LEFT)
        tk.Label(start_date_card, text="年", font=("微软雅黑", 10), fg="#6B7280", bg="#F3F4F6").pack(side=tk.LEFT, padx=(2, 6))
        
        # 月输入框
        month_entry = tk.Entry(
            start_date_card, 
            textvariable=self.start_month_var, 
            font=("微软雅黑", 11, "bold"), 
            width=3, 
            justify="center",
            bg="white",
            fg="#1F2937",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#D1D5DB",
            highlightcolor="#5B8DEE"
        )
        month_entry.pack(side=tk.LEFT)
        tk.Label(start_date_card, text="月", font=("微软雅黑", 10), fg="#6B7280", bg="#F3F4F6").pack(side=tk.LEFT, padx=(2, 6))
        
        # 日输入框
        day_entry = tk.Entry(
            start_date_card, 
            textvariable=self.start_day_var, 
            font=("微软雅黑", 11, "bold"), 
            width=3, 
            justify="center",
            bg="white",
            fg="#1F2937",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#D1D5DB",
            highlightcolor="#5B8DEE"
        )
        day_entry.pack(side=tk.LEFT)
        tk.Label(start_date_card, text="日", font=("微软雅黑", 10), fg="#6B7280", bg="#F3F4F6").pack(side=tk.LEFT, padx=(2, 0))
        
        start_time_frame = tk.Frame(start_frame, bg=self.colors["card"])
        start_time_frame.pack(anchor=tk.W, pady=(8, 0))
        
        self.start_hour_var = tk.StringVar(value=str(current_date.hour))
        self.start_minute_var = tk.StringVar(value=str(current_date.minute))
        
        # 使用超酷的ModernTimeEntry！
        hour_entry = ModernTimeEntry(
            start_time_frame,
            text_variable=self.start_hour_var,
            width=70,
            height=55,
            font_size=20
        )
        hour_entry.pack(side=tk.LEFT)
        
        # 超酷的冒号分隔符！
        colon_label = tk.Label(
            start_time_frame,
            text=":",
            font=("微软雅黑", 28, 'bold'),
            fg="#6B7280",
            bg=self.colors["card"]
        )
        colon_label.pack(side=tk.LEFT, padx=12)
        
        minute_entry = ModernTimeEntry(
            start_time_frame,
            text_variable=self.start_minute_var,
            width=70,
            height=55,
            font_size=20
        )
        minute_entry.pack(side=tk.LEFT)
        
        # 结束时间容器 - 同样超酷！
        end_frame = tk.Frame(time_inputs_frame, bg=self.colors["card"])
        end_frame.pack(side=tk.LEFT, padx=80)
        
        tk.Label(
            end_frame, 
            text="🏁 结束时间", 
            font=("微软雅黑", 11, 'bold'), 
            fg="#374151", 
            bg=self.colors["card"]
        ).pack(anchor=tk.W)
        
        # 结束日期选择 - 现代化卡片式设计
        end_date_frame = tk.Frame(end_frame, bg=self.colors["card"])
        end_date_frame.pack(anchor=tk.W, pady=(8, 0))
        
        self.end_year_var = tk.StringVar(value=str(current_date.year))
        self.end_month_var = tk.StringVar(value=str(current_date.month))
        self.end_day_var = tk.StringVar(value=str(current_date.day))
        
        # 日期选择容器 - 圆角卡片效果
        end_date_card = tk.Frame(end_date_frame, bg="#F3F4F6", padx=12, pady=8)
        end_date_card.pack(side=tk.LEFT)
        end_date_card.config(highlightbackground="#E5E7EB", highlightcolor="#5B8DEE", highlightthickness=1)
        
        # 📅 日期图标
        tk.Label(end_date_card, text="📅", font=("微软雅黑", 12), bg="#F3F4F6").pack(side=tk.LEFT, padx=(0, 8))
        
        # 年输入框 - 现代化样式
        end_year_entry = tk.Entry(
            end_date_card, 
            textvariable=self.end_year_var, 
            font=("微软雅黑", 11, "bold"), 
            width=5, 
            justify="center",
            bg="white",
            fg="#1F2937",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#D1D5DB",
            highlightcolor="#5B8DEE"
        )
        end_year_entry.pack(side=tk.LEFT)
        tk.Label(end_date_card, text="年", font=("微软雅黑", 10), fg="#6B7280", bg="#F3F4F6").pack(side=tk.LEFT, padx=(2, 6))
        
        # 月输入框
        end_month_entry = tk.Entry(
            end_date_card, 
            textvariable=self.end_month_var, 
            font=("微软雅黑", 11, "bold"), 
            width=3, 
            justify="center",
            bg="white",
            fg="#1F2937",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#D1D5DB",
            highlightcolor="#5B8DEE"
        )
        end_month_entry.pack(side=tk.LEFT)
        tk.Label(end_date_card, text="月", font=("微软雅黑", 10), fg="#6B7280", bg="#F3F4F6").pack(side=tk.LEFT, padx=(2, 6))
        
        # 日输入框
        end_day_entry = tk.Entry(
            end_date_card, 
            textvariable=self.end_day_var, 
            font=("微软雅黑", 11, "bold"), 
            width=3, 
            justify="center",
            bg="white",
            fg="#1F2937",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#D1D5DB",
            highlightcolor="#5B8DEE"
        )
        end_day_entry.pack(side=tk.LEFT)
        tk.Label(end_date_card, text="日", font=("微软雅黑", 10), fg="#6B7280", bg="#F3F4F6").pack(side=tk.LEFT, padx=(2, 0))
        
        end_time_frame = tk.Frame(end_frame, bg=self.colors["card"])
        end_time_frame.pack(anchor=tk.W, pady=(8, 0))
        
        self.end_hour_var = tk.StringVar(value=str(current_date.hour))
        self.end_minute_var = tk.StringVar(value=str(current_date.minute))
        
        # 同样使用超酷的ModernTimeEntry！
        end_hour_entry = ModernTimeEntry(
            end_time_frame,
            text_variable=self.end_hour_var,
            width=70,
            height=55,
            font_size=20
        )
        end_hour_entry.pack(side=tk.LEFT)
        
        # 超酷的冒号分隔符！
        end_colon_label = tk.Label(
            end_time_frame,
            text=":",
            font=("微软雅黑", 28, 'bold'),
            fg="#6B7280",
            bg=self.colors["card"]
        )
        end_colon_label.pack(side=tk.LEFT, padx=12)
        
        end_minute_entry = ModernTimeEntry(
            end_time_frame,
            text_variable=self.end_minute_var,
            width=70,
            height=55,
            font_size=20
        )
        end_minute_entry.pack(side=tk.LEFT)
        
        # 启动结束时间自动刷新（每秒更新）
        self._start_end_time_auto_update()
        
        # 时间格式提示
        tk.Label(
            time_inputs_frame, 
            text="24小时制", 
            font=("微软雅黑", 9), 
            fg="#999999", 
            bg=self.colors["card"]
        ).pack(side=tk.LEFT, pady=(25, 0))
        
        # 第三部分：工作内容输入区域
        content_card = tk.Frame(main_container, bg=self.colors["card"], padx=20, pady=10)
        content_card.pack(fill=tk.X, padx=15, pady=(0, 10))
        # 添加卡片阴影效果
        content_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        # 活动类型选择 - 平铺按钮形式，直观快捷！
        activity_frame = tk.Frame(content_card, bg=self.colors["card"])
        activity_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(
            activity_frame, 
            text="🎯 活动类型:", 
            font=("微软雅黑", 12, 'bold'), 
            fg="#374151", 
            bg=self.colors["card"]
        ).pack(anchor=tk.W, pady=(0, 10))
        
        # 活动类型平铺按钮容器
        self.activity_var = tk.StringVar(value="价值工作")
        activity_options = ["价值工作", "聊天", "饮食", "复盘思考", "娱乐", "专业学习", "AI运用", "前沿咨询", "资本运作", "处理杂事", "杂活", "力量训练"]
        
        # 创建按钮容器
        buttons_container = tk.Frame(activity_frame, bg=self.colors["card"])
        buttons_container.pack(fill=tk.X)
        
        # 为每个活动类型创建一个可选按钮
        self.activity_buttons = {}  # 存储按钮引用，用于更新选中状态
        
        # 定义每个活动类型的颜色（用于区分不同类型）
        activity_colors = {
            "价值工作": ("#3B82F6", "#2563EB"),      # 蓝色
            "聊天": ("#F59E0B", "#D97706"),          # 橙色
            "饮食": ("#10B981", "#059669"),          # 绿色
            "复盘思考": ("#8B5CF6", "#7C3AED"),      # 紫色
            "娱乐": ("#EC4899", "#DB2777"),          # 粉色
            "专业学习": ("#06B6D4", "#0891B2"),      # 青色
            "AI运用": ("#6366F1", "#4F46E5"),        # 靛蓝色
            "前沿咨询": ("#14B8A6", "#0D9488"),      #  teal色
            "资本运作": ("#F97316", "#EA580C"),      # 深橙色
            "处理杂事": ("#6B7280", "#4B5563"),      # 灰色
            "杂活": ("#9CA3AF", "#6B7280"),          # 浅灰色
            "力量训练": ("#DC2626", "#B91C1C"),      # 红色
        }
        
        def create_activity_button(parent, activity, normal_color, hover_color):
            """创建一个活动类型按钮"""
            btn_frame = tk.Frame(parent, bg=self.colors["card"])
            btn_frame.pack(side=tk.LEFT, padx=3, pady=3)
            
            # 创建圆角按钮效果
            btn = tk.Label(
                btn_frame,
                text=activity,
                font=("微软雅黑", 10, "bold"),
                fg="white",
                bg=normal_color,
                padx=12,
                pady=6,
                cursor="hand2",
                relief="flat"
            )
            btn.pack()
            
            # 添加圆角效果（通过配置）
            btn.config(highlightthickness=0)
            
            def on_click(event):
                # 更新选中状态
                self.activity_var.set(activity)
                self._update_activity_button_styles()
            
            def on_enter(event):
                if self.activity_var.get() != activity:
                    btn.config(bg=hover_color)
            
            def on_leave(event):
                self._update_activity_button_styles()
            
            btn.bind("<Button-1>", on_click)
            btn.bind("<Enter>", on_enter)
            btn.bind("<Leave>", on_leave)
            
            return btn
        
        # 创建所有活动类型按钮
        for activity in activity_options:
            normal_color, hover_color = activity_colors.get(activity, ("#6B7280", "#4B5563"))
            btn = create_activity_button(buttons_container, activity, normal_color, hover_color)
            self.activity_buttons[activity] = (btn, normal_color, hover_color)
        
        # 初始化按钮样式
        self._update_activity_button_styles()
        
        tk.Label(
            content_card, 
            text="📝 工作内容", 
            font=("微软雅黑", 12, "bold"), 
            fg=self.colors["dark"], 
            bg=self.colors["card"]
        ).pack(anchor=tk.W, pady=(10, 5))
        
        # 文本框容器（高度缩小）
        text_frame = tk.Frame(content_card)
        text_frame.pack(fill=tk.X)
        
        # 优化文本框样式（更柔和的边框和间距）
        self.content_text = tk.Text(
            text_frame, 
            font=("微软雅黑", 11),
            wrap=tk.WORD,
            bd=1,
            relief="solid",
            bg="#fafafa",
            padx=15,
            pady=10,
            height=3,
            highlightthickness=1,
            highlightbackground="#e0e0e0",
            highlightcolor="#5B8DEE"
        )
        self.content_text.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # 文本框滚动条
        text_scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=self.content_text.yview)
        text_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.content_text.config(yscrollcommand=text_scrollbar.set)
        
        # 第四部分：按钮区域
        button_card = tk.Frame(main_container, bg=self.colors["background"], padx=20, pady=5)
        button_card.pack(fill=tk.X, padx=15, pady=(0, 10))
        
        # 创建超酷的现代化圆角按钮！
        # 保存记录按钮 - 渐变绿色
        save_button = ModernRoundedButton(
            button_card,
            text="✓ 保存记录",
            command=self.save_record,
            bg_color="#4ADE80",  # 鲜艳的薄荷绿
            hover_color="#22C55E",  # 悬停时的深绿色
            corner_radius=20,  # 超大圆角，更有个性！
            width=150,
            height=55,
            font_size=13
        )
        save_button.pack(side=tk.LEFT, padx=10, pady=5)
        
        # 清除内容按钮 - 渐变橙色
        clear_button = ModernRoundedButton(
            button_card,
            text="✕ 清除内容",
            command=self.clear_content,
            bg_color="#FB923C",  # 温暖的橙色
            hover_color="#F97316",  # 悬停时的深橙色
            corner_radius=20,
            width=150,
            height=55,
            font_size=13
        )
        clear_button.pack(side=tk.LEFT, padx=10, pady=5)
        
        # 删除选中按钮 - 渐变红色
        delete_button = ModernRoundedButton(
            button_card,
            text="🗑️ 删除选中",
            command=self.delete_selected_record,
            bg_color="#F87171",  # 柔和的红色
            hover_color="#EF4444",  # 悬停时的深红色
            corner_radius=20,
            width=150,
            height=55,
            font_size=13
        )
        delete_button.pack(side=tk.LEFT, padx=10, pady=5)
        
        # 导出Excel按钮 - 渐变蓝色
        export_button = ModernRoundedButton(
            button_card,
            text="📊 导出Excel",
            command=self.export_to_excel,
            bg_color="#60A5FA",  # 清爽的蓝色
            hover_color="#3B82F6",  # 悬停时的深蓝色
            corner_radius=20,
            width=150,
            height=55,
            font_size=13
        )
        export_button.pack(side=tk.LEFT, padx=10, pady=5)
        

        
        # 第五部分：记录列表 - 这是最重要的部分，需要优先扩展
        list_card = tk.Frame(main_container, bg=self.colors["card"], padx=20, pady=10)
        list_card.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))
        # 添加卡片阴影效果
        list_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        tk.Label(
            list_card, 
            text="📋 已保存的记录", 
            font=("微软雅黑", 12, "bold"), 
            fg=self.colors["dark"], 
            bg=self.colors["card"]
        ).pack(anchor=tk.W, pady=(0, 5))
        
        # 表格容器
        list_frame = tk.Frame(list_card)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        # 定义表格的列（新增活动类型）
        columns = ("start_time", "end_time", "duration", "activity_type", "content")
        self.record_tree = ttk.Treeview(
            list_frame, 
            columns=columns, 
            show="headings"
        )
        
        # 设置列标题和宽度（所有列都能自适应，内容列优先扩展）
        self.record_tree.heading("start_time", text="起始时间")
        self.record_tree.heading("end_time", text="结束时间")
        self.record_tree.heading("duration", text="时长")
        self.record_tree.heading("activity_type", text="类型")
        self.record_tree.heading("content", text="工作内容")
        self.record_tree.column("start_time", width=120, anchor="center", stretch=True)
        self.record_tree.column("end_time", width=120, anchor="center", stretch=True)
        self.record_tree.column("duration", width=80, anchor="center", stretch=True)
        self.record_tree.column("activity_type", width=60, anchor="center", stretch=True)
        self.record_tree.column("content", width=300, stretch=True)
        
        # 确保表格能自适应窗口大小
        self.record_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 绑定双击事件 - 双击记录可以编辑
        self.record_tree.bind("<Double-1>", self.on_record_double_click)
        
        # 表格滚动条
        tree_scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.record_tree.yview)
        tree_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.record_tree.config(yscrollcommand=tree_scrollbar.set)
        
        # 配置Treeview样式（更清晰的配色）
        # 注意：style变量已经在前面定义过了，直接使用即可
        
        # 配置Treeview主体
        style.configure(
            "Treeview",
            background="#f5f5f5",  # 浅灰色背景
            foreground="#333333",  # 深灰色文字，提高对比度
            fieldbackground="#ffffff",  # 单元格白色背景
            rowheight=32,  # 增加行高，让文字更易读
            font=("微软雅黑", 10)  # 稍大字体
        )
        
        # 配置Treeview表头 - 保持鲜艳但清晰的样式，增加内边距
        style.configure(
            "Treeview.Heading",
            background=self.colors["primary"],
            foreground="#ffffff",
            font=("微软雅黑", 10, "bold"),
            padding=10,
            relief="flat"
        )
        
        # 配置选中状态 - 明显的选中效果
        style.map("Treeview", 
                  background=[("selected", "#e3f2fd")],
                  foreground=[("selected", "#1976d2")])
        
        # 为输入框添加现代圆润样式
        style.configure('TEntry',
                       fieldbackground='#f8f8f8',
                       borderwidth=1,
                       relief='solid',
                       padding=8,
                       font=('微软雅黑', 10))
        
        # 为组合框添加现代圆润样式
        style.configure('TCombobox',
                       fieldbackground='#f8f8f8',
                       borderwidth=1,
                       relief='solid',
                       padding=8,
                       font=('微软雅黑', 10))
    
    def setup_statistics_tab(self):
        """
        设置统计页签
        支持按年、月、日三个维度查看统计，按活动类型统计时长
        """
        # 创建统计页签
        self.stats_tab = tk.Frame(self.notebook, bg="#F5F7FA")
        self.notebook.add(self.stats_tab, text="📊 统计")
        
        # 创建滚动容器框架
        stats_scroll_frame = tk.Frame(self.stats_tab, bg="#F5F7FA")
        stats_scroll_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建Canvas用于滚动
        stats_canvas = tk.Canvas(stats_scroll_frame, bg="#F5F7FA", highlightthickness=0)
        stats_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 创建垂直滚动条
        stats_vscrollbar = ttk.Scrollbar(stats_scroll_frame, orient="vertical", command=stats_canvas.yview)
        stats_vscrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 创建水平滚动条
        stats_hscrollbar = ttk.Scrollbar(self.stats_tab, orient="horizontal", command=stats_canvas.xview)
        stats_hscrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # 配置Canvas的滚动命令
        stats_canvas.configure(yscrollcommand=stats_vscrollbar.set, xscrollcommand=stats_hscrollbar.set)
        
        # 创建内部容器，设置最小宽度确保内容显示完整
        stats_container = tk.Frame(stats_canvas, bg="#F5F7FA")
        stats_canvas_window = stats_canvas.create_window((0, 0), window=stats_container, anchor="nw", width=1000)
        
        # 配置Canvas和容器
        def _on_stats_configure(event):
            # 设置内部窗口宽度为Canvas宽度或最小1000像素，确保图例等内容显示完整
            min_width = max(event.width, 1000)
            stats_canvas.itemconfig(stats_canvas_window, width=min_width)
            stats_canvas.configure(scrollregion=stats_canvas.bbox("all"))
        
        stats_canvas.bind('<Configure>', _on_stats_configure)
        stats_container.bind("<Configure>", lambda e: stats_canvas.configure(scrollregion=stats_canvas.bbox("all")))
        
        # 绑定鼠标滚轮事件，支持在程序任何位置滚动
        def _on_stats_mousewheel(event):
            # 获取当前活动的页签
            current_tab = self.notebook.index(self.notebook.select())
            # 1是统计页签，只有统计页签需要处理滚动
            if current_tab != 1:
                return
            
            # 获取鼠标位置下的组件
            try:
                widget_under_mouse = self.root.winfo_containing(event.x_root, event.y_root)
            except:
                widget_under_mouse = None
            
            # 如果鼠标在文本输入框或多行文本框上，让输入框自己处理滚动
            if widget_under_mouse:
                if isinstance(widget_under_mouse, (tk.Entry, tk.Text)):
                    return
                parent = widget_under_mouse.winfo_parent()
                if parent:
                    try:
                        parent_widget = widget_under_mouse.nametowidget(parent)
                        if isinstance(parent_widget, tk.Text):
                            return
                    except:
                        pass
            
            # 检查是否按住Shift键，如果是则水平滚动
            if event.state & 0x1:  # Shift键被按下
                stats_canvas.xview_scroll(int(-1*(event.delta/120)), "units")
            else:
                stats_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            return "break"
        
        # 绑定水平滚动（Shift+滚轮）
        def _on_stats_shift_mousewheel(event):
            current_tab = self.notebook.index(self.notebook.select())
            if current_tab != 1:
                return
            stats_canvas.xview_scroll(int(-1*(event.delta/120)), "units")
            return "break"
        
        # 绑定到主窗口，实现全局滚动
        self.root.bind("<MouseWheel>", _on_stats_mousewheel, add="+")
        self.root.bind("<Shift-MouseWheel>", _on_stats_shift_mousewheel, add="+")
        
        # 为所有子组件也绑定滚轮事件，确保点击后也能滚动
        def bind_stats_mousewheel_to_children(widget):
            """递归为所有子组件绑定鼠标滚轮事件"""
            for child in widget.winfo_children():
                if not isinstance(child, (tk.Canvas, ttk.Scrollbar)):
                    child.bind("<MouseWheel>", _on_stats_mousewheel, add="+")
                    child.bind("<Shift-MouseWheel>", _on_stats_shift_mousewheel, add="+")
                bind_stats_mousewheel_to_children(child)
        
        bind_stats_mousewheel_to_children(stats_container)
        
        # ========== 标题区域 ==========
        title_card = tk.Frame(stats_container, bg=self.colors["primary"], padx=20, pady=15)
        title_card.pack(fill=tk.X, padx=15, pady=(15, 10))
        title_card.config(highlightbackground="#cccccc", highlightcolor="#999999", highlightthickness=2)
        
        tk.Label(
            title_card, 
            text="📊 时间统计", 
            font=("微软雅黑", 18, "bold"), 
            fg="white", 
            bg=self.colors["primary"]
        ).pack(side=tk.LEFT)
        
        # ========== 时间区间选择区域 ==========
        date_range_card = tk.Frame(stats_container, bg="white", padx=20, pady=15)
        date_range_card.pack(fill=tk.X, padx=15, pady=(0, 10))
        date_range_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        tk.Label(
            date_range_card,
            text="📅 时间区间:",
            font=("微软雅黑", 12, 'bold'),
            fg="#374151",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 15))
        
        # 默认显示系统当前日期
        today = datetime.now()
        
        # 开始日期
        start_date_frame = tk.Frame(date_range_card, bg="white")
        start_date_frame.pack(side=tk.LEFT, padx=(0, 10))
        
        tk.Label(
            start_date_frame,
            text="开始日期:",
            font=("微软雅黑", 10),
            fg="#6B7280",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        # 开始日期变量 - 默认当前日期（使用独立的变量名）
        self.stats_start_year_var = tk.StringVar(value=str(today.year))
        self.stats_start_month_var = tk.StringVar(value=str(today.month))
        self.stats_start_day_var = tk.StringVar(value=str(today.day))
        
        # 开始日期输入框
        start_year_entry = ModernTimeEntry(
            start_date_frame,
            text_variable=self.stats_start_year_var,
            width=70,
            height=40,
            font_size=14
        )
        start_year_entry.pack(side=tk.LEFT)
        
        tk.Label(start_date_frame, text="年", font=("微软雅黑", 11), bg="white").pack(side=tk.LEFT, padx=2)
        
        start_month_entry = ModernTimeEntry(
            start_date_frame,
            text_variable=self.stats_start_month_var,
            width=50,
            height=40,
            font_size=14
        )
        start_month_entry.pack(side=tk.LEFT)
        
        tk.Label(start_date_frame, text="月", font=("微软雅黑", 11), bg="white").pack(side=tk.LEFT, padx=2)
        
        start_day_entry = ModernTimeEntry(
            start_date_frame,
            text_variable=self.stats_start_day_var,
            width=50,
            height=40,
            font_size=14
        )
        start_day_entry.pack(side=tk.LEFT)
        
        tk.Label(start_date_frame, text="日", font=("微软雅黑", 11), bg="white").pack(side=tk.LEFT, padx=2)
        
        # 结束日期
        end_date_frame = tk.Frame(date_range_card, bg="white")
        end_date_frame.pack(side=tk.LEFT, padx=(20, 10))
        
        tk.Label(
            end_date_frame,
            text="结束日期:",
            font=("微软雅黑", 10),
            fg="#6B7280",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        # 结束日期变量 - 默认当前日期（使用独立的变量名）
        self.stats_end_year_var = tk.StringVar(value=str(today.year))
        self.stats_end_month_var = tk.StringVar(value=str(today.month))
        self.stats_end_day_var = tk.StringVar(value=str(today.day))
        
        # 结束日期输入框
        end_year_entry = ModernTimeEntry(
            end_date_frame,
            text_variable=self.stats_end_year_var,
            width=70,
            height=40,
            font_size=14
        )
        end_year_entry.pack(side=tk.LEFT)
        
        tk.Label(end_date_frame, text="年", font=("微软雅黑", 11), bg="white").pack(side=tk.LEFT, padx=2)
        
        end_month_entry = ModernTimeEntry(
            end_date_frame,
            text_variable=self.stats_end_month_var,
            width=50,
            height=40,
            font_size=14
        )
        end_month_entry.pack(side=tk.LEFT)
        
        tk.Label(end_date_frame, text="月", font=("微软雅黑", 11), bg="white").pack(side=tk.LEFT, padx=2)
        
        end_day_entry = ModernTimeEntry(
            end_date_frame,
            text_variable=self.stats_end_day_var,
            width=50,
            height=40,
            font_size=14
        )
        end_day_entry.pack(side=tk.LEFT)
        
        tk.Label(end_date_frame, text="日", font=("微软雅黑", 11), bg="white").pack(side=tk.LEFT, padx=2)
        
        # 应用按钮
        apply_btn = ModernRoundedButton(
            date_range_card,
            text="✓ 应用",
            command=self.apply_date_range,
            bg_color="#10B981",
            hover_color="#059669",
            corner_radius=12,
            width=100,
            height=40,
            font_size=11
        )
        apply_btn.pack(side=tk.LEFT, padx=(20, 5))
        
        # 重置按钮
        reset_btn = ModernRoundedButton(
            date_range_card,
            text="↺ 重置",
            command=self.reset_date_range,
            bg_color="#6B7280",
            hover_color="#4B5563",
            corner_radius=12,
            width=100,
            height=40,
            font_size=11
        )
        reset_btn.pack(side=tk.LEFT, padx=5)
        
        # ========== 图表类型切换区域 ==========
        filter_card = tk.Frame(stats_container, bg="white", padx=20, pady=15)
        filter_card.pack(fill=tk.X, padx=15, pady=(0, 10))
        filter_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        tk.Label(
            filter_card,
            text="📊 显示方式:",
            font=("微软雅黑", 12, 'bold'),
            fg="#374151",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 15))
        
        # 显示方式变量
        self.chart_type = tk.StringVar(value="table")
        
        # 统计维度变量（按年、月、日）
        self.stats_dimension = tk.StringVar(value="day")  # 默认按日统计
        
        # 图表类型按钮框架
        chart_type_frame = tk.Frame(filter_card, bg="white")
        chart_type_frame.pack(side=tk.LEFT)
        
        tk.Label(
            chart_type_frame,
            text="📊 显示方式:",
            font=("微软雅黑", 11),
            fg="#6B7280",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 10))
        
        # 表格按钮
        table_btn = ModernRoundedButton(
            chart_type_frame,
            text="📋 表格",
            command=lambda: self.change_chart_type("table"),
            bg_color="#E5E7EB",
            hover_color="#D1D5DB",
            text_color="#374151",
            corner_radius=12,
            width=90,
            height=38,
            font_size=11
        )
        table_btn.pack(side=tk.LEFT, padx=3)
        
        # 扇形图按钮
        pie_btn = ModernRoundedButton(
            chart_type_frame,
            text="🥧 扇形图",
            command=lambda: self.change_chart_type("pie"),
            bg_color="#F472B6",
            hover_color="#EC4899",
            corner_radius=12,
            width=90,
            height=38,
            font_size=11
        )
        pie_btn.pack(side=tk.LEFT, padx=3)
        
        # ========== 统计结果显示区域 ==========
        self.stats_result_card = tk.Frame(stats_container, bg="white", padx=20, pady=15)
        self.stats_result_card.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))
        self.stats_result_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        # 标题
        self.stats_title_label = tk.Label(
            self.stats_result_card,
            text="📈 统计结果",
            font=("微软雅黑", 14, "bold"),
            fg="#374151",
            bg="white"
        )
        self.stats_title_label.pack(anchor=tk.W, pady=(0, 10))
        
        # 创建内容容器（用于切换表格和图表）
        self.stats_content_frame = tk.Frame(self.stats_result_card, bg="white")
        self.stats_content_frame.pack(fill=tk.BOTH, expand=True)
        
        # 统计表格
        self.setup_stats_treeview()
        
        # 初始化显示统计
        self.refresh_statistics()
    
    def setup_stats_treeview(self):
        """
        设置统计表格
        """
        # 表格容器（放到内容容器中）
        self.tree_frame = tk.Frame(self.stats_content_frame, bg="white")
        self.tree_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建表格（按活动类型统计）
        columns = ("activity_type", "work_content", "total_duration", "record_count", "percentage")
        self.stats_tree = ttk.Treeview(
            self.tree_frame,
            columns=columns,
            show="headings"
        )
        
        # 设置列标题
        self.stats_tree.heading("activity_type", text="活动类型")
        self.stats_tree.heading("work_content", text="工作内容")
        self.stats_tree.heading("total_duration", text="总时长")
        self.stats_tree.heading("record_count", text="记录数")
        self.stats_tree.heading("percentage", text="占比")
        
        # 设置列宽
        self.stats_tree.column("activity_type", width=100, anchor="center")
        self.stats_tree.column("work_content", width=300, anchor="center")
        self.stats_tree.column("total_duration", width=120, anchor="center")
        self.stats_tree.column("record_count", width=80, anchor="center")
        self.stats_tree.column("percentage", width=80, anchor="center")
        
        self.stats_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 滚动条
        scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.stats_tree.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.stats_tree.config(yscrollcommand=scrollbar.set)
        
        # 配置样式
        style = ttk.Style()
        style.configure(
            "Treeview",
            background="#f5f5f5",
            foreground="#333333",
            fieldbackground="#ffffff",
            rowheight=35,
            font=("微软雅黑", 11)
        )
        style.configure(
            "Treeview.Heading",
            background="#5B8DEE",
            foreground="#ffffff",
            font=("微软雅黑", 11, "bold"),
            padding=10
        )
        style.map("Treeview",
                 background=[("selected", "#e3f2fd")],
                 foreground=[("selected", "#1976d2")])
    
    def change_chart_type(self, chart_type):
        """
        切换图表类型（表格或扇形图）
        """
        self.chart_type.set(chart_type)
        self.refresh_statistics()
    
    def show_pie_chart(self, stats):
        """
        显示扇形图
        """
        # 清除之前的内容
        for widget in self.stats_content_frame.winfo_children():
            widget.destroy()
        
        # 创建图表容器
        chart_frame = tk.Frame(self.stats_content_frame, bg="white")
        chart_frame.pack(fill=tk.BOTH, expand=True)
        
        # 准备数据 - 按活动类型汇总（不区分工作内容）
        activity_totals = {}
        for period, activities in stats.items():
            for key, data in activities.items():
                # 从数据中获取活动类型（key可能是"活动类型|工作内容"的组合）
                activity_type = data.get("activity_type", key)
                if activity_type not in activity_totals:
                    activity_totals[activity_type] = 0
                activity_totals[activity_type] += data["total_minutes"]
        
        if not activity_totals:
            # 没有数据时显示提示
            tk.Label(
                chart_frame,
                text="暂无数据",
                font=("微软雅黑", 16),
                fg="#9CA3AF",
                bg="white"
            ).pack(expand=True)
            return
        
        # 准备扇形图数据
        labels = list(activity_totals.keys())
        sizes = list(activity_totals.values())
        
        # 计算百分比
        total = sum(sizes)
        
        # 超酷的配色方案
        colors = ['#60A5FA', '#34D399', '#F472B6', '#FBBF24', '#A78BFA', 
                  '#F87171', '#22D3EE', '#FB923C', '#C084FC']
        
        # 创建matplotlib图形
        fig = Figure(figsize=(8, 6), dpi=100, facecolor='white')
        ax = fig.add_subplot(111)
        
        # 绘制扇形图
        wedges, texts, autotexts = ax.pie(
            sizes,
            labels=labels,
            colors=colors[:len(labels)],
            autopct=lambda pct: f'{pct:.1f}%' if pct > 5 else '',
            startangle=90,
            textprops={'fontsize': 11, 'fontfamily': 'Microsoft YaHei'},
            pctdistance=0.75
        )
        
        # 设置百分比文字样式
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
            autotext.set_fontsize(10)
        
        # 设置标签样式
        for text in texts:
            text.set_fontsize(12)
            text.set_fontweight('bold')
        
        # 添加标题
        ax.set_title("按活动类型统计 - 时间占比", fontsize=16, fontweight='bold', 
                    fontfamily='Microsoft YaHei', pad=20)
        
        # 确保圆形
        ax.axis('equal')
        
        # 创建Canvas并嵌入到Tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def show_table_view(self, stats):
        """
        显示表格视图
        """
        # 清除之前的内容
        for widget in self.stats_content_frame.winfo_children():
            widget.destroy()
        
        # 重新创建表格
        self.setup_stats_treeview()
        
        # 填充数据（新的数据结构：按活动类型和工作内容组合统计）
        for period, activities in stats.items():
            for key, data in sorted(activities.items(), key=lambda x: x[1]["total_minutes"], reverse=True):
                total_minutes = data["total_minutes"]
                record_count = data["count"]
                activity_type = data["activity_type"]
                work_content = data["work_content"]
                
                # 格式化时长
                hours = total_minutes // 60
                minutes = total_minutes % 60
                if hours > 0:
                    duration_str = f"{hours}小时{minutes}分钟"
                else:
                    duration_str = f"{minutes}分钟"
                
                # 计算百分比
                total_all = sum(a["total_minutes"] for a in activities.values())
                percentage = (total_minutes / total_all * 100) if total_all > 0 else 0
                
                # 限制工作内容显示长度
                if len(work_content) > 50:
                    work_content_str = work_content[:47] + "..."
                else:
                    work_content_str = work_content
                
                self.stats_tree.insert("", tk.END, values=(
                    activity_type,
                    work_content_str,
                    duration_str,
                    f"{record_count}条",
                    f"{percentage:.1f}%"
                ))
    
    def apply_date_range(self):
        """
        应用时间区间筛选
        """
        try:
            # 获取开始日期
            start_year = int(self.stats_start_year_var.get())
            start_month = int(self.stats_start_month_var.get())
            start_day = int(self.stats_start_day_var.get())
            
            # 获取结束日期
            end_year = int(self.stats_end_year_var.get())
            end_month = int(self.stats_end_month_var.get())
            end_day = int(self.stats_end_day_var.get())
            
            # 验证日期有效性
            try:
                start_date = datetime(start_year, start_month, start_day)
                end_date = datetime(end_year, end_month, end_day)
            except ValueError:
                messagebox.showerror("日期错误", "请输入有效的日期")
                return
            
            # 验证开始日期不晚于结束日期
            if start_date > end_date:
                messagebox.showerror("日期错误", "开始日期不能晚于结束日期")
                return
            
            # 刷新统计
            self.refresh_statistics()
            
        except ValueError:
            messagebox.showerror("输入错误", "请输入有效的数字")
    
    def reset_date_range(self):
        """
        重置时间区间为当前系统日期
        """
        today = datetime.now()
        
        # 重置开始日期为当前日期
        self.stats_start_year_var.set(str(today.year))
        self.stats_start_month_var.set(str(today.month))
        self.stats_start_day_var.set(str(today.day))
        
        # 重置结束日期为当前日期
        self.stats_end_year_var.set(str(today.year))
        self.stats_end_month_var.set(str(today.month))
        self.stats_end_day_var.set(str(today.day))
        
        # 刷新统计
        self.refresh_statistics()
    
    def get_filtered_records(self):
        """
        获取时间区间筛选后的记录
        """
        try:
            # 获取开始日期
            start_year = int(self.stats_start_year_var.get())
            start_month = int(self.stats_start_month_var.get())
            start_day = int(self.stats_start_day_var.get())
            
            # 获取结束日期
            end_year = int(self.stats_end_year_var.get())
            end_month = int(self.stats_end_month_var.get())
            end_day = int(self.stats_end_day_var.get())
            
            # 调试输出
            print(f"DEBUG: 总记录数: {len(self.records)}")
            print(f"DEBUG: 筛选范围: {start_year}-{start_month:02d}-{start_day:02d} 到 {end_year}-{end_month:02d}-{end_day:02d}")
            
            # 筛选在日期区间内的记录
            filtered = []
            for record in self.records:
                # 构建记录日期和区间日期用于比较
                record_date = (record.year, record.month, record.day)
                start_date = (start_year, start_month, start_day)
                end_date = (end_year, end_month, end_day)
                
                # 检查记录是否在区间内（包含边界）
                if start_date <= record_date <= end_date:
                    filtered.append(record)
            
            print(f"DEBUG: 筛选后记录数: {len(filtered)}")
            return filtered
        except ValueError as e:
            # 如果日期格式错误，返回所有记录
            print(f"DEBUG: 日期格式错误: {e}")
            return self.records
    
    def change_stats_dimension(self, dimension):
        """
        切换统计维度
        """
        self.stats_dimension.set(dimension)
        self.refresh_statistics()
    
    def refresh_statistics(self):
        """
        刷新统计数据
        """
        # 获取筛选后的记录
        filtered_records = self.get_filtered_records()
        
        if not filtered_records:
            # 没有记录时显示提示
            self.stats_title_label.config(text="📈 统计结果 - 暂无数据")
            # 清空内容区域
            for widget in self.stats_content_frame.winfo_children():
                widget.destroy()
            tk.Label(
                self.stats_content_frame,
                text="暂无数据",
                font=("微软雅黑", 16),
                fg="#9CA3AF",
                bg="white"
            ).pack(expand=True)
            return
        
        chart_type = self.chart_type.get()
        
        # 按活动类型统计（使用筛选后的记录）
        stats = self.calculate_stats_by_activity(filtered_records)
        self.stats_title_label.config(text="📈 统计结果")
        
        # 根据图表类型显示不同的视图
        if chart_type == "pie":
            self.show_pie_chart(stats)
        else:
            self.show_table_view(stats)
    
    def calculate_stats_by_year(self, records=None):
        """
        按年统计
        """
        if records is None:
            records = self.records
            
        stats = {}
        for record in records:
            year = record.year
            period = f"{year}年"
            
            if period not in stats:
                stats[period] = {}
            
            activity = record.activity_type
            if activity not in stats[period]:
                stats[period][activity] = {"total_minutes": 0, "count": 0}
            
            stats[period][activity]["total_minutes"] += record.get_duration_minutes()
            stats[period][activity]["count"] += 1
        
        return stats
    
    def calculate_stats_by_month(self, records=None):
        """
        按月统计
        """
        if records is None:
            records = self.records
            
        stats = {}
        for record in records:
            period = f"{record.year}年{record.month:02d}月"
            
            if period not in stats:
                stats[period] = {}
            
            activity = record.activity_type
            if activity not in stats[period]:
                stats[period][activity] = {"total_minutes": 0, "count": 0}
            
            stats[period][activity]["total_minutes"] += record.get_duration_minutes()
            stats[period][activity]["count"] += 1
        
        return stats
    
    def calculate_stats_by_day(self, records=None):
        """
        按日统计
        """
        if records is None:
            records = self.records
            
        stats = {}
        for record in records:
            period = f"{record.year}年{record.month:02d}月{record.day:02d}日"
            
            if period not in stats:
                stats[period] = {}
            
            activity = record.activity_type
            if activity not in stats[period]:
                stats[period][activity] = {"total_minutes": 0, "count": 0}
            
            stats[period][activity]["total_minutes"] += record.get_duration_minutes()
            stats[period][activity]["count"] += 1
        
        return stats
    
    def calculate_stats_by_activity(self, records=None):
        """
        按活动类型和工作内容组合统计（用于时间区间统计）
        返回格式：{"活动类型|工作内容": {"total_minutes": 总分钟数, "count": 记录数, "activity_type": 活动类型, "work_content": 工作内容}}
        """
        if records is None:
            records = self.records
            
        stats = {"按活动类型统计": {}}  # 使用统一的key，与之前的格式兼容
        
        for record in records:
            activity = record.activity_type
            content = record.content.strip() if record.content.strip() else "未填写"
            
            # 使用"活动类型|工作内容"作为唯一key
            key = f"{activity}|{content}"
            
            if key not in stats["按活动类型统计"]:
                stats["按活动类型统计"][key] = {
                    "total_minutes": 0, 
                    "count": 0,
                    "activity_type": activity,
                    "work_content": content
                }
            
            stats["按活动类型统计"][key]["total_minutes"] += record.get_duration_minutes()
            stats["按活动类型统计"][key]["count"] += 1
        
        return stats
    
    def setup_ai_analysis_tab(self):
        """
        设置AI分析页签
        使用DeepSeek API分析时间使用情况并提供建议
        """
        # 创建AI分析页签
        self.ai_tab = tk.Frame(self.notebook, bg="#F5F7FA")
        self.notebook.add(self.ai_tab, text="🤖 AI分析")
        
        # 创建滚动容器框架
        ai_scroll_frame = tk.Frame(self.ai_tab, bg="#F5F7FA")
        ai_scroll_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建Canvas用于滚动
        ai_canvas = tk.Canvas(ai_scroll_frame, bg="#F5F7FA", highlightthickness=0)
        ai_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 创建垂直滚动条
        ai_vscrollbar = ttk.Scrollbar(ai_scroll_frame, orient="vertical", command=ai_canvas.yview)
        ai_vscrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 配置Canvas的滚动命令（只保留垂直滚动）
        ai_canvas.configure(yscrollcommand=ai_vscrollbar.set)
        
        # 创建内部容器，设置最小高度确保内容显示完整
        # 不设置固定宽度，让容器根据内容自动调整
        ai_container = tk.Frame(ai_canvas, bg="#F5F7FA")
        ai_canvas_window = ai_canvas.create_window((0, 0), window=ai_container, anchor="nw")
        
        def _on_ai_configure(event):
            # 设置内部窗口宽度为Canvas宽度
            ai_canvas.itemconfig(ai_canvas_window, width=event.width)
            ai_canvas.configure(scrollregion=ai_canvas.bbox("all"))
        
        ai_canvas.bind('<Configure>', _on_ai_configure)
        ai_container.bind("<Configure>", lambda e: ai_canvas.configure(scrollregion=ai_canvas.bbox("all")))
        
        # 绑定鼠标滚轮事件，支持在程序任何位置滚动
        def _on_ai_mousewheel(event):
            # 获取当前活动的页签
            current_tab = self.notebook.index(self.notebook.select())
            # 2是AI分析页签，只有AI分析页签需要处理滚动
            if current_tab != 2:
                return
            
            # 获取鼠标位置下的组件
            try:
                widget_under_mouse = self.root.winfo_containing(event.x_root, event.y_root)
            except:
                widget_under_mouse = None
            
            # 如果鼠标在文本输入框或多行文本框上，让输入框自己处理滚动
            if widget_under_mouse:
                if isinstance(widget_under_mouse, (tk.Entry, tk.Text)):
                    return
                parent = widget_under_mouse.winfo_parent()
                if parent:
                    try:
                        parent_widget = widget_under_mouse.nametowidget(parent)
                        if isinstance(parent_widget, tk.Text):
                            return
                    except:
                        pass
            
            # 滚动Canvas
            ai_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            return "break"
        
        # 绑定到主窗口，实现全局滚动
        self.root.bind("<MouseWheel>", _on_ai_mousewheel, add="+")
        
        # 为所有子组件也绑定滚轮事件，确保点击后也能滚动
        def bind_ai_mousewheel_to_children(widget):
            """递归为所有子组件绑定鼠标滚轮事件"""
            for child in widget.winfo_children():
                if not isinstance(child, (tk.Canvas, ttk.Scrollbar)):
                    child.bind("<MouseWheel>", _on_ai_mousewheel, add="+")
                bind_ai_mousewheel_to_children(child)
        
        bind_ai_mousewheel_to_children(ai_container)
        
        # ========== 标题区域 ==========
        title_card = tk.Frame(ai_container, bg="#8B5CF6", padx=20, pady=15)
        title_card.pack(fill=tk.X, padx=15, pady=(15, 10))
        title_card.config(highlightbackground="#7C3AED", highlightcolor="#6D28D9", highlightthickness=2)
        
        tk.Label(
            title_card, 
            text="🤖 AI智能时间分析", 
            font=("微软雅黑", 18, "bold"), 
            fg="white", 
            bg="#8B5CF6"
        ).pack(side=tk.LEFT)
        
        tk.Label(
            title_card,
            text="Powered by DeepSeek",
            font=("微软雅黑", 10),
            fg="#E9D5FF",
            bg="#8B5CF6"
        ).pack(side=tk.RIGHT)
        
        # ========== API密钥设置区域 ==========
        api_card = tk.Frame(ai_container, bg="white", padx=20, pady=15)
        api_card.pack(fill=tk.X, padx=15, pady=(0, 10))
        api_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        tk.Label(
            api_card,
            text="🔑 API密钥:",
            font=("微软雅黑", 11, 'bold'),
            fg="#374151",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 10))
        
        # API密钥输入框
        self.api_key_var = tk.StringVar()
        self.api_entry = tk.Entry(
            api_card,
            textvariable=self.api_key_var,
            font=("微软雅黑", 11),
            width=40,
            show="*"
        )
        self.api_entry.pack(side=tk.LEFT, padx=(0, 10))
        
        # 加载已保存的API密钥
        try:
            with open('config.json', 'r', encoding='utf-8') as f:
                config = json.load(f)
                self.api_key_var.set(config.get('deepseek_api_key', ''))
        except:
            pass
        
        # 保存API密钥按钮
        save_api_btn = ModernRoundedButton(
            api_card,
            text="💾 保存密钥",
            command=self.save_api_key,
            bg_color="#10B981",
            hover_color="#059669",
            corner_radius=10,
            width=110,
            height=35,
            font_size=10
        )
        save_api_btn.pack(side=tk.LEFT, padx=5)
        
        # 显示/隐藏密钥按钮
        self.show_api_key = False
        toggle_btn = ModernRoundedButton(
            api_card,
            text="👁️ 显示",
            command=self.toggle_api_key_visibility,
            bg_color="#6B7280",
            hover_color="#4B5563",
            corner_radius=10,
            width=80,
            height=35,
            font_size=10
        )
        toggle_btn.pack(side=tk.LEFT, padx=5)
        
        # 提示词设置按钮
        prompt_btn = ModernRoundedButton(
            api_card,
            text="📝 提示词设置",
            command=self.open_prompt_settings,
            bg_color="#8B5CF6",
            hover_color="#7C3AED",
            corner_radius=10,
            width=120,
            height=35,
            font_size=10
        )
        prompt_btn.pack(side=tk.LEFT, padx=5)
        
        # ========== 时间区间选择区域 ==========
        range_card = tk.Frame(ai_container, bg="white", padx=20, pady=15)
        range_card.pack(fill=tk.X, padx=15, pady=(0, 10))
        range_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        tk.Label(
            range_card,
            text="📅 分析区间:",
            font=("微软雅黑", 11, 'bold'),
            fg="#374151",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 10))
        
        # 使用全部数据按钮 - 默认不勾选
        self.ai_use_all_data = tk.BooleanVar(value=False)
        all_data_check = tk.Checkbutton(
            range_card,
            text="使用全部数据",
            variable=self.ai_use_all_data,
            font=("微软雅黑", 10),
            bg="white",
            command=self.toggle_ai_date_range
        )
        all_data_check.pack(side=tk.LEFT, padx=(0, 20))
        
        # 自定义区间框架
        self.ai_date_frame = tk.Frame(range_card, bg="white")
        self.ai_date_frame.pack(side=tk.LEFT)
        
        # 开始日期
        tk.Label(
            self.ai_date_frame,
            text="开始:",
            font=("微软雅黑", 10),
            fg="#6B7280",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        self.ai_start_date_var = tk.StringVar()
        ai_start_entry = tk.Entry(
            self.ai_date_frame,
            textvariable=self.ai_start_date_var,
            font=("微软雅黑", 10),
            width=12
        )
        ai_start_entry.pack(side=tk.LEFT, padx=(0, 10))
        
        # 结束日期
        tk.Label(
            self.ai_date_frame,
            text="结束:",
            font=("微软雅黑", 10),
            fg="#6B7280",
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        self.ai_end_date_var = tk.StringVar()
        ai_end_entry = tk.Entry(
            self.ai_date_frame,
            textvariable=self.ai_end_date_var,
            font=("微软雅黑", 10),
            width=12
        )
        ai_end_entry.pack(side=tk.LEFT)
        
        # 初始化日期 - 默认当前系统日期
        today = datetime.now()
        self.ai_start_date_var.set(f"{today.year:04d}-{today.month:02d}-{today.day:02d}")
        self.ai_end_date_var.set(f"{today.year:04d}-{today.month:02d}-{today.day:02d}")
        
        # 默认禁用日期输入
        self.toggle_ai_date_range()
        
        # ========== 分析按钮区域 ==========
        btn_card = tk.Frame(ai_container, bg="white", padx=20, pady=15)
        btn_card.pack(fill=tk.X, padx=15, pady=(0, 10))
        btn_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        # 开始分析按钮
        analyze_btn = ModernRoundedButton(
            btn_card,
            text="🚀 开始AI分析",
            command=self.start_ai_analysis,
            bg_color="#8B5CF6",
            hover_color="#7C3AED",
            corner_radius=15,
            width=180,
            height=50,
            font_size=14
        )
        analyze_btn.pack(side=tk.LEFT, padx=(0, 15))
        
        # 分析状态标签
        self.ai_status_label = tk.Label(
            btn_card,
            text="点击按钮开始分析您的时间使用情况",
            font=("微软雅黑", 11),
            fg="#6B7280",
            bg="white"
        )
        self.ai_status_label.pack(side=tk.LEFT)
        
        # ========== 分析结果显示区域 ==========
        result_card = tk.Frame(ai_container, bg="white", padx=20, pady=15)
        result_card.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))
        result_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        tk.Label(
            result_card,
            text="📊 分析结果",
            font=("微软雅黑", 14, "bold"),
            fg="#374151",
            bg="white"
        ).pack(anchor=tk.W, pady=(0, 10))
        
        # 创建文本显示区域，根据内容自动调整高度
        # 使用WORD换行模式在单词边界自动换行
        self.ai_result_text = tk.Text(
            result_card,
            font=("微软雅黑", 11),
            wrap=tk.WORD,
            padx=15,
            pady=15,
            height=1  # 初始高度为1，会根据内容自动调整
        )
        self.ai_result_text.pack(fill=tk.X, expand=False)
        
        # 绑定内容变化事件，自动调整高度
        def adjust_text_height(event=None):
            """根据内容自动调整文本框高度"""
            # 获取内容的行数
            num_lines = int(self.ai_result_text.index('end-1c').split('.')[0])
            # 设置最小高度为10行，最大高度为50行
            new_height = max(10, min(num_lines + 2, 50))
            self.ai_result_text.config(height=new_height)
        
        self.ai_result_text.bind('<KeyRelease>', adjust_text_height)
        self.ai_result_text.bind('<ButtonRelease>', adjust_text_height)
        # 保存调整函数，供外部调用
        self.ai_result_text.adjust_height = adjust_text_height
        
        # 尝试加载并显示上次保存的AI分析结果
        self.display_saved_ai_result()
        
        # 如果没有保存的结果，显示默认提示信息
        result, _ = self.load_ai_result()
        if not result:
            self.ai_result_text.insert(tk.END, "欢迎使用AI智能时间分析！\n\n")
            self.ai_result_text.insert(tk.END, "使用说明：\n")
            self.ai_result_text.insert(tk.END, "1. 在上方输入您的DeepSeek API密钥（如果没有，请访问 https://platform.deepseek.com 获取）\n")
            self.ai_result_text.insert(tk.END, "2. 选择要分析的时间区间（全部数据或自定义区间）\n")
            self.ai_result_text.insert(tk.END, "3. 点击\"🚀 开始AI分析\"按钮\n")
            self.ai_result_text.insert(tk.END, "4. 等待AI生成分析报告...\n\n")
            self.ai_result_text.insert(tk.END, "AI将为您分析：\n")
            self.ai_result_text.insert(tk.END, "✓ 时间使用模式分析\n")
            self.ai_result_text.insert(tk.END, "✓ 时间分配合理性评估\n")
            self.ai_result_text.insert(tk.END, "✓ 个性化时间管理建议\n")
            self.ai_result_text.insert(tk.END, "✓ 每日/每周时间规划模板\n")
            self.ai_result_text.config(state=tk.DISABLED)
        
        # 初始化AI分析器
        self.ai_analyzer = TimeAnalyzer()
    
    def save_api_key(self):
        """
        保存API密钥
        """
        api_key = self.api_key_var.get().strip()
        if not api_key:
            messagebox.showwarning("警告", "请输入API密钥")
            return
        
        self.ai_analyzer.set_api_key(api_key)
        messagebox.showinfo("成功", "API密钥已保存")
    
    def toggle_api_key_visibility(self):
        """
        切换API密钥显示/隐藏
        """
        self.show_api_key = not self.show_api_key
        # 切换输入框的show属性
        if self.show_api_key:
            self.api_entry.config(show="")
        else:
            self.api_entry.config(show="*")
    
    def open_prompt_settings(self):
        """
        打开提示词设置窗口
        """
        # 创建提示词设置窗口
        prompt_window = tk.Toplevel(self.root)
        prompt_window.title("📝 AI提示词设置")
        prompt_window.geometry("800x700")
        prompt_window.configure(bg="#F5F7FA")
        
        # 设置窗口最小大小
        prompt_window.minsize(700, 600)
        
        # 创建滚动容器
        canvas = tk.Canvas(prompt_window, bg="#F5F7FA", highlightthickness=0)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(prompt_window, orient="vertical", command=canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        container = tk.Frame(canvas, bg="#F5F7FA")
        canvas_window = canvas.create_window((0, 0), window=container, anchor="nw")
        
        def on_configure(event):
            canvas.itemconfig(canvas_window, width=event.width)
            canvas.configure(scrollregion=canvas.bbox("all"))
        
        canvas.bind('<Configure>', on_configure)
        container.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", on_mousewheel)
        
        # ========== 标题区域 ==========
        title_card = tk.Frame(container, bg="#8B5CF6", padx=20, pady=15)
        title_card.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(
            title_card,
            text="📝 AI提示词设置",
            font=("微软雅黑", 16, "bold"),
            fg="white",
            bg="#8B5CF6"
        ).pack(side=tk.LEFT)
        
        # 说明文字
        info_card = tk.Frame(container, bg="#E0F2FE", padx=15, pady=10)
        info_card.pack(fill=tk.X, pady=(0, 15))
        
        info_text = """💡 提示词说明：
• 系统提示词：定义AI的角色和身份，影响AI回答的风格和角度
• 用户提示词模板：定义AI分析的具体内容和格式

可用变量（在用户提示词模板中使用）：
• {time_range_text} - 时间范围描述
• {record_count} - 记录总数
• {total_hours} - 总时长（小时）
• {time_distribution} - 时间分配详情
• {activity_details} - 各活动类型详情"""
        
        tk.Label(
            info_card,
            text=info_text,
            font=("微软雅黑", 10),
            fg="#0369A1",
            bg="#E0F2FE",
            justify=tk.LEFT
        ).pack(anchor=tk.W)
        
        # ========== 系统提示词区域 ==========
        system_card = tk.Frame(container, bg="white", padx=15, pady=10)
        system_card.pack(fill=tk.X, pady=(0, 10))
        system_card.config(highlightbackground="#e0e0e0", highlightcolor="#c0c0c0", highlightthickness=1)
        
        tk.Label(
            system_card,
            text="🤖 系统提示词（定义AI角色）",
            font=("微软雅黑", 11, "bold"),
            fg="#374151",
            bg="white"
        ).pack(anchor=tk.W, pady=(0, 5))
        
        # 系统提示词输入框，增加高度
        self.system_prompt_text = tk.Text(
            system_card,
            font=("微软雅黑", 10),
            wrap=tk.WORD,
            height=25,
            padx=10,
            pady=10,
            bg="#F8FAFC",
            relief="solid",
            bd=1
        )
        self.system_prompt_text.pack(fill=tk.BOTH, expand=True)
        self.system_prompt_text.insert(tk.END, self.ai_analyzer.get_system_prompt())
        
        # 隐藏的用户提示词输入框（用于保存功能兼容性）
        self.user_prompt_text = tk.Text(container, font=("微软雅黑", 10), height=1)
        self.user_prompt_text.insert(tk.END, self.ai_analyzer.get_user_prompt_template())
        
        # ========== 按钮区域 ==========
        button_card = tk.Frame(container, bg="#F5F7FA", padx=15, pady=10)
        button_card.pack(fill=tk.X)
        
        # 保存按钮
        save_btn = ModernRoundedButton(
            button_card,
            text="💾 保存设置",
            command=lambda: self.save_prompt_settings(prompt_window),
            bg_color="#10B981",
            hover_color="#059669",
            corner_radius=10,
            width=130,
            height=40,
            font_size=11
        )
        save_btn.pack(side=tk.LEFT, padx=5)
        
        # 恢复默认按钮
        reset_btn = ModernRoundedButton(
            button_card,
            text="🔄 恢复默认",
            command=lambda: self.reset_prompt_settings(),
            bg_color="#F59E0B",
            hover_color="#D97706",
            corner_radius=10,
            width=130,
            height=40,
            font_size=11
        )
        reset_btn.pack(side=tk.LEFT, padx=5)
        
        # 取消按钮
        cancel_btn = ModernRoundedButton(
            button_card,
            text="✕ 取消",
            command=prompt_window.destroy,
            bg_color="#6B7280",
            hover_color="#4B5563",
            corner_radius=10,
            width=100,
            height=40,
            font_size=11
        )
        cancel_btn.pack(side=tk.LEFT, padx=5)
    
    def save_prompt_settings(self, window):
        """
        保存提示词设置
        """
        system_prompt = self.system_prompt_text.get(1.0, tk.END).strip()
        user_prompt_template = self.user_prompt_text.get(1.0, tk.END).strip()
        
        if not system_prompt:
            messagebox.showwarning("警告", "系统提示词不能为空")
            return
        
        if not user_prompt_template:
            messagebox.showwarning("警告", "用户提示词模板不能为空")
            return
        
        # 检查模板变量是否完整
        required_vars = ['{time_range_text}', '{record_count}', '{total_hours}', 
                        '{time_distribution}', '{activity_details}']
        missing_vars = []
        for var in required_vars:
            if var not in user_prompt_template:
                missing_vars.append(var)
        
        if missing_vars:
            result = messagebox.askyesno(
                "变量缺失警告",
                f"用户提示词模板中缺少以下变量：\n{', '.join(missing_vars)}\n\n"
                f"缺少这些变量可能导致分析结果不完整。\n是否仍要保存？"
            )
            if not result:
                return
        
        # 保存设置
        if self.ai_analyzer.save_prompt_settings(system_prompt, user_prompt_template):
            messagebox.showinfo("成功", "提示词设置已保存！")
            window.destroy()
        else:
            messagebox.showerror("错误", "保存提示词设置失败")
    
    def reset_prompt_settings(self):
        """
        恢复默认提示词设置
        """
        result = messagebox.askyesno(
            "确认恢复",
            "确定要恢复默认提示词设置吗？\n这将覆盖您当前的自定义设置。"
        )
        
        if result:
            if self.ai_analyzer.reset_to_default_prompts():
                # 更新文本框内容
                self.system_prompt_text.delete(1.0, tk.END)
                self.system_prompt_text.insert(tk.END, self.ai_analyzer.get_system_prompt())
                
                self.user_prompt_text.delete(1.0, tk.END)
                self.user_prompt_text.insert(tk.END, self.ai_analyzer.get_user_prompt_template())
                
                messagebox.showinfo("成功", "已恢复默认提示词设置！")
    
    def toggle_ai_date_range(self):
        """
        切换AI分析日期区间的启用状态
        """
        if self.ai_use_all_data.get():
            # 禁用日期输入
            for widget in self.ai_date_frame.winfo_children():
                if isinstance(widget, tk.Entry):
                    widget.config(state=tk.DISABLED)
        else:
            # 启用日期输入
            for widget in self.ai_date_frame.winfo_children():
                if isinstance(widget, tk.Entry):
                    widget.config(state=tk.NORMAL)
    
    def start_ai_analysis(self):
        """
        开始AI分析
        """
        # 检查API密钥
        api_key = self.api_key_var.get().strip()
        if not api_key:
            messagebox.showwarning("警告", "请先输入DeepSeek API密钥")
            return
        
        # 设置API密钥
        self.ai_analyzer.set_api_key(api_key)
        
        # 获取要分析的记录
        if self.ai_use_all_data.get():
            # 使用全部记录
            records_to_analyze = self.records
            time_range = "全部时间"
        else:
            # 使用自定义区间
            try:
                start_date_str = self.ai_start_date_var.get()
                end_date_str = self.ai_end_date_var.get()
                
                start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
                end_date = datetime.strptime(end_date_str, "%Y-%m-%d")
                
                # 筛选记录
                records_to_analyze = []
                for record in self.records:
                    record_date = datetime(record.year, record.month, record.day)
                    if start_date <= record_date <= end_date:
                        records_to_analyze.append(record)
                
                time_range = f"{start_date_str} 至 {end_date_str}"
            except ValueError:
                messagebox.showerror("错误", "日期格式不正确，请使用YYYY-MM-DD格式")
                return
        
        if not records_to_analyze:
            messagebox.showwarning("警告", "选定时间区间内没有记录")
            return
        
        # 更新状态
        self.ai_status_label.config(text="⏳ 正在分析中，请稍候...", fg="#8B5CF6")
        self.root.update()
        
        # 准备数据
        records_data = []
        for record in records_to_analyze:
            records_data.append({
                "activity_type": record.activity_type,
                "duration_minutes": record.get_duration_minutes(),
                "content": record.content,
                "date": f"{record.year}-{record.month:02d}-{record.day:02d}"
            })
        
        # 调用AI分析
        try:
            result = self.ai_analyzer.analyze_time_usage(records_data, time_range)
            
            # 显示结果
            self.display_ai_result(result)
            
            if result["success"]:
                self.ai_status_label.config(text="✅ 分析完成", fg="#10B981")
            else:
                self.ai_status_label.config(text=f"❌ {result['error']}", fg="#EF4444")
                
        except Exception as e:
            self.ai_status_label.config(text=f"❌ 分析失败: {str(e)}", fg="#EF4444")
            messagebox.showerror("错误", f"AI分析失败: {str(e)}")
    
    def display_ai_result(self, result):
        """
        显示AI分析结果，并保存到文件
        """
        self.ai_result_text.config(state=tk.NORMAL)
        self.ai_result_text.delete(1.0, tk.END)
        
        if not result["success"]:
            self.ai_result_text.insert(tk.END, f"分析失败：{result['error']}\n")
            self.ai_result_text.config(state=tk.DISABLED)
            return
        
        # 显示数据概况
        self.ai_result_text.insert(tk.END, "=" * 50 + "\n")
        self.ai_result_text.insert(tk.END, "📊 数据概况\n")
        self.ai_result_text.insert(tk.END, "=" * 50 + "\n\n")
        self.ai_result_text.insert(tk.END, f"总记录数：{result['record_count']} 条\n")
        self.ai_result_text.insert(tk.END, f"总时长：{result['total_hours']} 小时\n\n")
        
        # 显示时间分配
        self.ai_result_text.insert(tk.END, "时间分配：\n")
        for activity, stats in result['time_distribution'].items():
            self.ai_result_text.insert(
                tk.END, 
                f"  • {activity}: {stats['hours']}小时{stats['minutes']}分钟 ({stats['percentage']}%)\n"
            )
        
        self.ai_result_text.insert(tk.END, "\n")
        
        # 显示AI分析结果
        self.ai_result_text.insert(tk.END, "=" * 50 + "\n")
        self.ai_result_text.insert(tk.END, "🤖 AI智能分析\n")
        self.ai_result_text.insert(tk.END, "=" * 50 + "\n\n")
        
        self.ai_result_text.insert(tk.END, result['analysis'])
        
        # 更新文本框高度以显示所有内容
        self.ai_result_text.update_idletasks()
        self.ai_result_text.adjust_height()
        
        self.ai_result_text.config(state=tk.DISABLED)
        
        # 保存分析结果到文件
        self.save_ai_result(result)
    
    def save_ai_result(self, result):
        """
        保存AI分析结果到JSON文件
        """
        try:
            # 添加保存时间戳
            result_with_timestamp = {
                "result": result,
                "saved_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            with open(AI_RESULT_FILE, 'w', encoding='utf-8') as f:
                json.dump(result_with_timestamp, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存AI分析结果时出错: {e}")
    
    def load_ai_result(self):
        """
        从JSON文件加载上次保存的AI分析结果
        """
        try:
            if os.path.exists(AI_RESULT_FILE):
                with open(AI_RESULT_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get("result"), data.get("saved_time")
            return None, None
        except Exception as e:
            print(f"加载AI分析结果时出错: {e}")
            return None, None
    
    def display_saved_ai_result(self):
        """
        显示上次保存的AI分析结果（如果有）
        """
        result, saved_time = self.load_ai_result()
        if result and result.get("success"):
            # 在结果前添加提示信息
            self.ai_result_text.config(state=tk.NORMAL)
            self.ai_result_text.delete(1.0, tk.END)
            
            # 显示上次分析时间
            self.ai_result_text.insert(tk.END, f"💾 上次分析时间: {saved_time}\n")
            self.ai_result_text.insert(tk.END, "=" * 50 + "\n\n")
            
            # 显示数据概况
            self.ai_result_text.insert(tk.END, "=" * 50 + "\n")
            self.ai_result_text.insert(tk.END, "📊 数据概况\n")
            self.ai_result_text.insert(tk.END, "=" * 50 + "\n\n")
            self.ai_result_text.insert(tk.END, f"总记录数：{result['record_count']} 条\n")
            self.ai_result_text.insert(tk.END, f"总时长：{result['total_hours']} 小时\n\n")
            
            # 显示时间分配
            self.ai_result_text.insert(tk.END, "时间分配：\n")
            for activity, stats in result['time_distribution'].items():
                self.ai_result_text.insert(
                    tk.END, 
                    f"  • {activity}: {stats['hours']}小时{stats['minutes']}分钟 ({stats['percentage']}%)\n"
                )
            
            self.ai_result_text.insert(tk.END, "\n")
            
            # 显示AI分析结果
            self.ai_result_text.insert(tk.END, "=" * 50 + "\n")
            self.ai_result_text.insert(tk.END, "🤖 AI智能分析\n")
            self.ai_result_text.insert(tk.END, "=" * 50 + "\n\n")
            
            self.ai_result_text.insert(tk.END, result['analysis'])
            
            # 更新文本框高度
            self.ai_result_text.update_idletasks()
            self.ai_result_text.adjust_height()
            
            self.ai_result_text.config(state=tk.DISABLED)
    
    def load_records(self):
        """
        从JSON文件加载之前保存的记录
        """
        try:
            if os.path.exists(DATA_FILE):
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.records = [TimeRecord.from_dict(item) for item in data]
        except Exception as e:
            messagebox.showerror("错误", f"加载记录时出错: {e}")
    
    def save_records(self):
        """
        保存所有记录到JSON文件
        """
        try:
            data = [record.to_dict() for record in self.records]
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            messagebox.showerror("错误", f"保存记录时出错: {e}")
    
    def save_record(self):
        """
        保存当前输入的时间记录
        """
        try:
            # 使用用户选择的起始日期和结束日期
            start_year = int(self.start_year_var.get())
            start_month = int(self.start_month_var.get())
            start_day = int(self.start_day_var.get())
            
            end_year = int(self.end_year_var.get())
            end_month = int(self.end_month_var.get())
            end_day = int(self.end_day_var.get())
            
            # 验证起始日期有效性
            try:
                datetime(start_year, start_month, start_day)
            except ValueError:
                messagebox.showerror("日期错误", "请输入有效的起始日期（年月日）")
                return
            
            # 验证结束日期有效性
            try:
                datetime(end_year, end_month, end_day)
            except ValueError:
                messagebox.showerror("日期错误", "请输入有效的结束日期（年月日）")
                return
            
            start_hour = int(self.start_hour_var.get())
            start_minute = int(self.start_minute_var.get())
            end_hour = int(self.end_hour_var.get())
            end_minute = int(self.end_minute_var.get())
            content = self.content_text.get("1.0", tk.END).strip()
            
            if start_hour < 0 or start_hour > 23:
                messagebox.showerror("输入错误", "起始小时必须在0-23之间")
                return
            if start_minute < 0 or start_minute > 59:
                messagebox.showerror("输入错误", "起始分钟必须在0-59之间")
                return
            if end_hour < 0 or end_hour > 23:
                messagebox.showerror("输入错误", "结束小时必须在0-23之间")
                return
            if end_minute < 0 or end_minute > 59:
                messagebox.showerror("输入错误", "结束分钟必须在0-59之间")
                return
            
        except ValueError:
            messagebox.showerror("输入错误", "请输入有效的数字")
            return
        
        if not content:
            messagebox.showwarning("内容为空", "请输入工作内容")
            return
        
        # 检查是否是编辑模式
        if self.editing_record_id is not None:
            # 编辑模式：找到并更新现有记录
            record_found = False
            for i, record in enumerate(self.records):
                if record.id == self.editing_record_id:
                    # 更新记录的所有字段
                    record.year = start_year
                    record.month = start_month
                    record.day = start_day
                    record.start_hour = start_hour
                    record.start_minute = start_minute
                    record.end_year = end_year
                    record.end_month = end_month
                    record.end_day = end_day
                    record.end_hour = end_hour
                    record.end_minute = end_minute
                    record.activity_type = self.activity_var.get()
                    record.content = content
                    
                    # 重新生成ID，因为时间可能变了
                    record.id = f"{start_year:04d}{start_month:02d}{start_day:02d}{start_hour:02d}{start_minute:02d}"
                    
                    record_found = True
                    break
            
            if record_found:
                messagebox.showinfo("编辑成功", "记录已更新！")
            else:
                messagebox.showerror("编辑失败", "找不到要编辑的记录")
                self.editing_record_id = None
                return
        else:
            # 新增模式：创建新记录
            new_record = TimeRecord(
                year=start_year,
                month=start_month,
                day=start_day,
                start_hour=start_hour,
                start_minute=start_minute,
                end_hour=end_hour,
                end_minute=end_minute,
                activity_type=self.activity_var.get(),
                content=content,
                end_year=end_year,
                end_month=end_month,
                end_day=end_day
            )
            self.records.append(new_record)
            messagebox.showinfo("保存成功", "新记录已添加！")
        
        self.save_records()
        self.refresh_record_list()
        
        # 保存当前结束时间，用于设置下一条记录的起始时间
        last_end_hour = end_hour
        last_end_minute = end_minute
        
        self.clear_content()
        
        # 设置下一条记录的起始时间为上次结束时间+1分钟
        self.set_next_start_time(last_end_hour, last_end_minute)
    
    def set_next_start_time(self, last_end_hour, last_end_minute):
        """
        设置下一条记录的起始时间为上次结束时间+1分钟
        """
        # 计算新的起始时间（+1分钟）
        new_start_minute = last_end_minute + 1
        new_start_hour = last_end_hour
        
        # 处理分钟进位
        if new_start_minute >= 60:
            new_start_minute = 0
            new_start_hour += 1
        
        # 处理小时进位（超过23点则回到0点）
        if new_start_hour >= 24:
            new_start_hour = 0
        
        # 更新起始时间输入框
        self.start_hour_var.set(str(new_start_hour))
        self.start_minute_var.set(str(new_start_minute))
        
        # 同时更新结束时间，默认为起始时间+30分钟
        new_end_minute = new_start_minute + 30
        new_end_hour = new_start_hour
        
        if new_end_minute >= 60:
            new_end_minute -= 60
            new_end_hour += 1
        
        if new_end_hour >= 24:
            new_end_hour = 0
        
        self.end_hour_var.set(str(new_end_hour))
        self.end_minute_var.set(str(new_end_minute))
    
    def _start_end_time_auto_update(self):
        """
        启动结束时间自动更新，每秒刷新为当前系统时间
        但在编辑模式下不自动更新
        """
        def update_end_time():
            # 只有在新增模式下才自动更新结束时间
            if self.editing_record_id is None:
                # 获取当前系统时间
                now = datetime.now()
                # 更新结束时间变量
                self.end_hour_var.set(str(now.hour))
                self.end_minute_var.set(str(now.minute))
            # 每秒检查一次
            self.root.after(1000, update_end_time)
        
        # 开始第一次更新
        update_end_time()
    
    def _update_activity_button_styles(self):
        """
        更新活动类型按钮的样式，高亮当前选中的按钮
        """
        selected_activity = self.activity_var.get()
        
        for activity, (btn, normal_color, hover_color) in self.activity_buttons.items():
            if activity == selected_activity:
                # 选中的按钮：使用更深的颜色，并添加边框效果
                btn.config(
                    bg=hover_color,
                    relief="solid",
                    bd=2,
                    highlightbackground="white",
                    highlightthickness=2
                )
            else:
                # 未选中的按钮：使用正常颜色，无边框
                btn.config(
                    bg=normal_color,
                    relief="flat",
                    bd=0,
                    highlightthickness=0
                )
    
    def clear_content(self):
        """
        清空输入框的内容，并重置编辑状态
        """
        self.content_text.delete("1.0", tk.END)
        self.editing_record_id = None
        # 更新状态标签
        self.status_label.config(text=" [新增模式]", fg="#999999")
        # 重置起始和结束日期为当前日期
        current_date = datetime.now()
        self.start_year_var.set(str(current_date.year))
        self.start_month_var.set(str(current_date.month))
        self.start_day_var.set(str(current_date.day))
        self.end_year_var.set(str(current_date.year))
        self.end_month_var.set(str(current_date.month))
        self.end_day_var.set(str(current_date.day))
        # 重置活动类型为默认值，并更新按钮样式
        self.activity_var.set("价值工作")
        self._update_activity_button_styles()
    
    def on_record_double_click(self, event):
        """
        双击记录时的处理：将记录信息填充到输入框，准备编辑
        """
        # 获取选中的项目
        selected_items = self.record_tree.selection()
        if not selected_items:
            return
        
        # 获取选中记录的值
        item = selected_items[0]
        item_values = self.record_tree.item(item)['values']
        if not item_values:
            return
        
        # 从起始时间字符串中解析出年月日时分
        # 格式示例："2026-03-27 14:30"
        start_datetime_str = item_values[0]
        end_datetime_str = item_values[1]
        
        # 解析起始时间
        start_date_part, start_time_part = start_datetime_str.split()
        start_year, start_month, start_day = map(int, start_date_part.split('-'))
        start_hour, start_minute = map(int, start_time_part.split(':'))
        
        # 解析结束时间
        end_date_part, end_time_part = end_datetime_str.split()
        end_year, end_month, end_day = map(int, end_date_part.split('-'))
        end_hour, end_minute = map(int, end_time_part.split(':'))
        
        # 获取活动类型和内容
        activity_type = item_values[3]
        content = item_values[4]
        
        # 找到对应的记录对象，获取其ID
        target_record = None
        for record in self.records:
            if record.get_start_datetime_str() == start_datetime_str:
                target_record = record
                break
        
        if target_record:
            # 填充起始日期输入框
            self.start_year_var.set(str(start_year))
            self.start_month_var.set(str(start_month))
            self.start_day_var.set(str(start_day))
            
            # 填充结束日期输入框
            self.end_year_var.set(str(end_year))
            self.end_month_var.set(str(end_month))
            self.end_day_var.set(str(end_day))
            
            # 填充时间输入框
            self.start_hour_var.set(str(start_hour))
            self.start_minute_var.set(str(start_minute))
            self.end_hour_var.set(str(end_hour))
            self.end_minute_var.set(str(end_minute))
            self.activity_var.set(activity_type)
            
            # 更新活动类型按钮样式
            self._update_activity_button_styles()
            
            # 填充工作内容
            self.content_text.delete("1.0", tk.END)
            self.content_text.insert("1.0", content)
            
            # 设置为编辑模式
            self.editing_record_id = target_record.id
            # 更新状态标签为编辑模式
            self.status_label.config(text=" [编辑模式]", fg="#5B8DEE")
    
    def refresh_record_list(self):
        """
        刷新记录列表的显示
        """
        for item in self.record_tree.get_children():
            self.record_tree.delete(item)
        
        sorted_records = sorted(self.records, key=lambda r: (r.year, r.month, r.day, r.start_hour, r.start_minute), reverse=True)
        
        for record in sorted_records:
            self.record_tree.insert("", tk.END, values=(
                record.get_start_datetime_str(),
                record.get_end_datetime_str(),
                record.get_duration_str(),
                record.activity_type,
                record.content
            ))
        
        # 刷新后将滚动条滚动到最顶部
        self.record_tree.yview_moveto(0)
    
    def delete_selected_record(self):
        """
        删除选中的记录
        """
        selected_item = self.record_tree.selection()
        if not selected_item:
            messagebox.showwarning("未选择", "请先选择要删除的记录")
            return
        
        item_values = self.record_tree.item(selected_item[0])['values']
        if not item_values:
            return
        
        start_datetime_str = item_values[0]
        for i, record in enumerate(self.records):
            if record.get_start_datetime_str() == start_datetime_str:
                del self.records[i]
                break
        
        self.save_records()
        self.refresh_record_list()
    
    def export_to_excel(self):
        """
        将所有记录导出为Excel文件
        """
        if not self.records:
            messagebox.showwarning("无记录", "没有可以导出的记录！")
            return
        
        try:
            # 弹出文件保存对话框，让用户选择保存位置和文件名
            # 默认文件名：时间记录_20260327.xlsx
            current_date = datetime.now()
            default_filename = f"时间记录_{current_date.year}{current_date.month:02d}{current_date.day:02d}.xlsx"
            
            # 显示文件保存对话框
            file_path = filedialog.asksaveasfilename(
                title="保存Excel文件",
                defaultextension=".xlsx",
                filetypes=[("Excel文件", "*.xlsx"), ("所有文件", "*.*")],
                initialfile=default_filename
            )
            
            # 如果用户取消了保存，就不继续
            if not file_path:
                return
            
            # 创建一个新的Excel工作簿
            wb = Workbook()
            # 获取当前活动的工作表
            ws = wb.active
            # 设置工作表标题
            ws.title = "工作时间记录"
            
            # ==========================================
            # 第一步：设置表头（第一行）
            # ==========================================
            headers = ["日期", "起始时间", "结束时间", "时长(分钟)", "活动类型", "工作内容"]
            ws.append(headers)
            
            # 设置表头样式
            # 定义表头字体：加粗、白色、12号
            header_font = Font(name='微软雅黑', size=12, bold=True, color='FFFFFF')
            # 定义表头填充色：蓝色背景
            header_fill = PatternFill(start_color='5B8DEE', end_color='5B8DEE', fill_type='solid')
            # 定义对齐方式：居中
            header_alignment = Alignment(horizontal='center', vertical='center')
            
            # 给表头的每个单元格应用样式
            for col_num, header in enumerate(headers, start=1):
                cell = ws.cell(row=1, column=col_num, value=header)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = header_alignment
            
            # ==========================================
            # 第二步：填充数据（从第二行开始）
            # ==========================================
            # 先把记录按时间从早到晚排序
            sorted_records = sorted(self.records, key=lambda r: (r.year, r.month, r.day, r.start_hour, r.start_minute))
            
            # 定义数据单元格样式
            data_font = Font(name='微软雅黑', size=11)
            data_alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            # 内容列左对齐
            content_alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
            
            # 定义边框（细线边框）
            thin_border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            # 填充每一行数据
            for row_num, record in enumerate(sorted_records, start=2):
                # 日期列：格式为 2026-03-27
                date_str = f"{record.year:04d}-{record.month:02d}-{record.day:02d}"
                # 起始时间：格式为 14:30
                start_time_str = f"{record.start_hour:02d}:{record.start_minute:02d}"
                # 结束时间：格式为 15:30
                end_time_str = f"{record.end_hour:02d}:{record.end_minute:02d}"
                # 时长（分钟）
                duration_minutes = record.get_duration_minutes()
                # 活动类型
                activity_type = record.activity_type
                # 工作内容
                content = record.content
                
                # 填充单元格
                ws.cell(row=row_num, column=1, value=date_str).font = data_font
                ws.cell(row=row_num, column=1).alignment = data_alignment
                ws.cell(row=row_num, column=1).border = thin_border
                
                ws.cell(row=row_num, column=2, value=start_time_str).font = data_font
                ws.cell(row=row_num, column=2).alignment = data_alignment
                ws.cell(row=row_num, column=2).border = thin_border
                
                ws.cell(row=row_num, column=3, value=end_time_str).font = data_font
                ws.cell(row=row_num, column=3).alignment = data_alignment
                ws.cell(row=row_num, column=3).border = thin_border
                
                ws.cell(row=row_num, column=4, value=duration_minutes).font = data_font
                ws.cell(row=row_num, column=4).alignment = data_alignment
                ws.cell(row=row_num, column=4).border = thin_border
                
                ws.cell(row=row_num, column=5, value=activity_type).font = data_font
                ws.cell(row=row_num, column=5).alignment = data_alignment
                ws.cell(row=row_num, column=5).border = thin_border
                
                ws.cell(row=row_num, column=6, value=content).font = data_font
                ws.cell(row=row_num, column=6).alignment = content_alignment
                ws.cell(row=row_num, column=6).border = thin_border
            
            # ==========================================
            # 第三步：调整列宽，让内容显示更美观
            # ==========================================
            # 列宽设置（根据内容设置合适的宽度）
            column_widths = [12, 10, 10, 12, 10, 40]
            for i, width in enumerate(column_widths, start=1):
                # Excel列名：A, B, C, ..., F
                col_letter = chr(64 + i)
                ws.column_dimensions[col_letter].width = width
            
            # 设置行高
            for row in ws.iter_rows():
                ws.row_dimensions[row[0].row].height = 25
            
            # ==========================================
            # 第四步：保存Excel文件
            # ==========================================
            wb.save(file_path)
            
            # 导出成功，提示用户
            messagebox.showinfo("导出成功", f"Excel文件已成功保存到：\n{file_path}")
            
        except Exception as e:
            messagebox.showerror("导出失败", f"导出Excel文件时出错：\n{str(e)}")

def main():
    """
    程序的主函数
    """
    root = tk.Tk()
    app = TimeTrackerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()