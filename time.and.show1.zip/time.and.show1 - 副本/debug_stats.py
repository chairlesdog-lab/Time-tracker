# 调试统计功能
import json
from datetime import datetime

# 读取记录
with open('time_records.json', 'r', encoding='utf-8') as f:
    records = json.load(f)

print(f"总共有 {len(records)} 条记录")

# 模拟筛选 2026-04-02 的记录
start_year, start_month, start_day = 2026, 4, 2
end_year, end_month, end_day = 2026, 4, 2

start_date = (start_year, start_month, start_day)
end_date = (end_year, end_month, end_day)

print(f"\n筛选日期范围: {start_year}-{start_month:02d}-{start_day:02d} 到 {end_year}-{end_month:02d}-{end_day:02d}")

# 筛选记录
filtered = []
for record in records:
    record_date = (record['year'], record['month'], record['day'])
    if start_date <= record_date <= end_date:
        filtered.append(record)

print(f"筛选后的记录数: {len(filtered)}")

if filtered:
    print("\n筛选到的记录:")
    for r in filtered:
        print(f"  {r['year']}-{r['month']:02d}-{r['day']:02d} {r['activity_type']} - {r['content']}")
else:
    print("\n没有筛选到记录")
    # 检查4月2日的记录
    print("\n检查4月2日的记录:")
    for r in records:
        if r['year'] == 2026 and r['month'] == 4 and r['day'] == 2:
            print(f"  找到: {r['year']}-{r['month']:02d}-{r['day']:02d} {r['activity_type']} - {r['content']}")
