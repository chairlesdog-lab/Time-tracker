"""
测试时间记录小程序的核心功能
这个测试文件用于验证数据保存、加载和基本功能是否正常
不需要启动GUI窗口
"""

import json
import os
import tempfile
import shutil
from time_tracker import TimeRecord, DATA_FILE

def test_time_record_class():
    """
    测试TimeRecord类的基本功能
    """
    print("测试TimeRecord类...")
    
    # 创建一条记录（只提供起始时间，结束时间默认为起始时间）
    record = TimeRecord(2026, 3, 26, 14, 30, content="编写代码")
    
    # 测试属性
    assert record.year == 2026
    assert record.month == 3
    assert record.day == 26
    assert record.start_hour == 14
    assert record.start_minute == 30
    assert record.end_hour == 14  # 默认与起始时间相同
    assert record.end_minute == 30  # 默认与起始时间相同
    assert record.content == "编写代码"
    assert record.id == "202603261430"
    
    # 测试字符串表示
    expected_str = "2026-03-26 14:30 - 2026-03-26 14:30 (0分钟) - 编写代码"
    assert str(record) == expected_str
    
    # 测试日期时间字符串
    assert record.get_start_datetime_str() == "2026-03-26 14:30"
    assert record.get_end_datetime_str() == "2026-03-26 14:30"
    
    # 测试时长计算
    assert record.get_duration_minutes() == 0
    assert record.get_duration_str() == "0分钟"
    
    # 测试字典转换
    record_dict = record.to_dict()
    assert record_dict["year"] == 2026
    assert record_dict["month"] == 3
    assert record_dict["day"] == 26
    assert record_dict["start_hour"] == 14
    assert record_dict["start_minute"] == 30
    assert record_dict["end_hour"] == 14
    assert record_dict["end_minute"] == 30
    assert record_dict["content"] == "编写代码"
    assert record_dict["id"] == "202603261430"
    
    # 测试从字典创建
    new_record = TimeRecord.from_dict(record_dict)
    assert new_record.year == record.year
    assert new_record.month == record.month
    assert new_record.day == record.day
    assert new_record.start_hour == record.start_hour
    assert new_record.start_minute == record.start_minute
    assert new_record.end_hour == record.end_hour
    assert new_record.end_minute == record.end_minute
    assert new_record.content == record.content
    
    print("  ✓ TimeRecord类测试通过")

def test_json_save_load():
    """
    测试JSON文件的保存和加载功能
    """
    print("测试JSON保存和加载...")
    
    # 使用临时目录进行测试
    temp_dir = tempfile.mkdtemp()
    original_data_file = DATA_FILE
    
    try:
        # 临时修改数据文件路径
        import time_tracker
        time_tracker.DATA_FILE = os.path.join(temp_dir, "test_records.json")
        
        # 创建测试记录
        records = [
            TimeRecord(2026, 3, 26, 9, 0, "晨会"),
            TimeRecord(2026, 3, 26, 10, 30, "编写代码"),
            TimeRecord(2026, 3, 26, 14, 0, "午餐休息")
        ]
        
        # 测试保存功能
        data = [record.to_dict() for record in records]
        with open(time_tracker.DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        # 验证文件存在
        assert os.path.exists(time_tracker.DATA_FILE)
        
        # 测试加载功能
        with open(time_tracker.DATA_FILE, 'r', encoding='utf-8') as f:
            loaded_data = json.load(f)
        
        # 验证加载的数据
        assert len(loaded_data) == 3
        assert loaded_data[0]["content"] == "晨会"
        assert loaded_data[1]["content"] == "编写代码"
        assert loaded_data[2]["content"] == "午餐休息"
        
        # 验证数据转换
        loaded_records = [TimeRecord.from_dict(item) for item in loaded_data]
        assert len(loaded_records) == 3
        assert loaded_records[0].start_hour == 9
        assert loaded_records[1].start_minute == 30
        assert loaded_records[2].content == "午餐休息"
        
        print("  ✓ JSON保存和加载测试通过")
        
    finally:
        # 恢复原始数据文件路径
        time_tracker.DATA_FILE = original_data_file
        # 清理临时目录
        shutil.rmtree(temp_dir)

def test_record_operations():
    """
    测试记录操作（排序、ID生成等）
    """
    print("测试记录操作...")
    
    # 创建多条记录
    records = [
        TimeRecord(2026, 3, 26, 9, 0, content="最早"),
        TimeRecord(2026, 3, 26, 18, 30, content="最晚"),
        TimeRecord(2026, 3, 26, 14, 0, content="中间")
    ]
    
    # 测试ID生成
    assert records[0].id == "202603260900"
    assert records[1].id == "202603261830"
    assert records[2].id == "202603261400"
    
    # 测试排序（按起始时间升序）
    sorted_records = sorted(records, key=lambda r: (r.year, r.month, r.day, r.start_hour, r.start_minute))
    assert sorted_records[0].content == "最早"
    assert sorted_records[1].content == "中间"
    assert sorted_records[2].content == "最晚"
    
    # 测试排序（按起始时间降序）
    sorted_records_desc = sorted(records, key=lambda r: (r.year, r.month, r.day, r.start_hour, r.start_minute), reverse=True)
    assert sorted_records_desc[0].content == "最晚"
    assert sorted_records_desc[1].content == "中间"
    assert sorted_records_desc[2].content == "最早"
    
    print("  ✓ 记录操作测试通过")

def run_all_tests():
    """
    运行所有测试
    """
    print("=" * 50)
    print("开始测试时间记录小程序")
    print("=" * 50)
    
    try:
        test_time_record_class()
        test_json_save_load()
        test_record_operations()
        
        print("=" * 50)
        print("所有测试通过！🎉")
        print("=" * 50)
        return True
    except AssertionError as e:
        print(f"测试失败: {e}")
        return False
    except Exception as e:
        print(f"测试过程中发生错误: {e}")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    if not success:
        exit(1)