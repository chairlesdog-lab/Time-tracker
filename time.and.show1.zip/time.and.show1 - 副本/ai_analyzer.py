"""
AI时间管理分析模块
使用DeepSeek API分析用户的时间使用习惯并提供建议
"""

import requests
import json
from typing import List, Dict, Any
from datetime import datetime


class TimeAnalyzer:
    """
    时间分析器类
    用于调用DeepSeek API分析时间使用情况
    """
    
    # DeepSeek API配置
    API_URL = "https://api.deepseek.com/v1/chat/completions"
    
    # 默认的系统提示词
    DEFAULT_SYSTEM_PROMPT = "你是一位专业的时间管理顾问，擅长分析时间使用模式并提供实用建议。"
    
    # 默认的用户提示词模板
    DEFAULT_USER_PROMPT_TEMPLATE = """你是一位专业的时间管理顾问。请深入分析用户的时间使用情况，特别关注具体的工作内容，并提供精准的建议。

## 用户数据概况
{time_range_text}，用户共记录了{record_count}条时间记录，总时长{total_hours}小时。

## 时间分配详情（按活动类型和工作内容细分）
{time_distribution}

## 各活动类型详情（包含具体工作内容）
{activity_details}

## 请提供以下深入分析（用中文回答）：

### 1. 时间使用深度分析
- 分析用户在每个活动类型下的具体工作内容分布
- 识别哪些具体工作内容占用了过多/过少时间
- 指出时间使用的深层模式和潜在问题（如：同一活动类型下工作内容过于分散、某些具体任务效率低下等）
- 分析工作内容之间的关联性和切换成本

### 2. 基于具体工作内容的精准建议
针对用户的具体工作内容，提供5-7条精准、可操作的建议：
- 哪些具体工作内容可以合并、优化或删减
- 如何重新安排具体任务的执行顺序和时间
- 针对高频出现的具体工作内容，给出效率提升方法
- 如何减少工作内容之间的无效切换
- 其他基于具体数据的改进建议

### 3. 个性化改进计划
根据用户的具体工作内容，提供一个详细的改进计划：
- 每日/每周时间规划建议
- 针对主要工作内容的优化策略
- 可量化的改进目标和检查点

请用友好、鼓励的语气，基于用户的具体工作内容给出专业且实用的建议。
"""
    
    def __init__(self, api_key: str = None):
        """
        初始化分析器
        
        参数:
        api_key: DeepSeek API密钥，如果为None则尝试从环境变量获取
        """
        self.api_key = api_key
        self.system_prompt = self.DEFAULT_SYSTEM_PROMPT
        self.user_prompt_template = self.DEFAULT_USER_PROMPT_TEMPLATE
        
        if not self.api_key:
            # 尝试从配置文件读取
            try:
                with open('config.json', 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    self.api_key = config.get('deepseek_api_key')
            except:
                pass
        
        # 加载保存的提示词设置
        self._load_prompt_settings()
    
    def set_api_key(self, api_key: str):
        """
        设置API密钥
        """
        self.api_key = api_key
        # 保存到配置文件
        try:
            config = {}
            try:
                with open('config.json', 'r', encoding='utf-8') as f:
                    config = json.load(f)
            except:
                pass
            
            config['deepseek_api_key'] = api_key
            
            with open('config.json', 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存配置失败: {e}")
    
    def _load_prompt_settings(self):
        """
        从配置文件加载提示词设置
        """
        try:
            with open('config.json', 'r', encoding='utf-8') as f:
                config = json.load(f)
                self.system_prompt = config.get('system_prompt', self.DEFAULT_SYSTEM_PROMPT)
                self.user_prompt_template = config.get('user_prompt_template', self.DEFAULT_USER_PROMPT_TEMPLATE)
        except:
            pass
    
    def save_prompt_settings(self, system_prompt: str = None, user_prompt_template: str = None):
        """
        保存提示词设置到配置文件
        
        参数:
        system_prompt: 系统提示词，如果为None则使用当前值
        user_prompt_template: 用户提示词模板，如果为None则使用当前值
        """
        if system_prompt is not None:
            self.system_prompt = system_prompt
        if user_prompt_template is not None:
            self.user_prompt_template = user_prompt_template
        
        try:
            config = {}
            try:
                with open('config.json', 'r', encoding='utf-8') as f:
                    config = json.load(f)
            except:
                pass
            
            config['system_prompt'] = self.system_prompt
            config['user_prompt_template'] = self.user_prompt_template
            
            with open('config.json', 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            
            return True
        except Exception as e:
            print(f"保存提示词设置失败: {e}")
            return False
    
    def get_system_prompt(self) -> str:
        """
        获取当前系统提示词
        """
        return self.system_prompt
    
    def get_user_prompt_template(self) -> str:
        """
        获取当前用户提示词模板
        """
        return self.user_prompt_template
    
    def reset_to_default_prompts(self):
        """
        重置提示词为默认值
        """
        self.system_prompt = self.DEFAULT_SYSTEM_PROMPT
        self.user_prompt_template = self.DEFAULT_USER_PROMPT_TEMPLATE
        return self.save_prompt_settings()
    
    def analyze_time_usage(self, records: List[Dict], time_range: str = None) -> Dict[str, Any]:
        """
        分析时间使用情况
        
        参数:
        records: 时间记录列表，每个记录包含activity_type, duration, content等字段
        time_range: 时间范围描述，如"2024年3月1日至3月31日"
        
        返回:
        包含分析结果和建议的字典
        """
        if not self.api_key:
            return {
                "success": False,
                "error": "请先设置DeepSeek API密钥",
                "analysis": "",
                "suggestions": []
            }
        
        # 准备数据摘要
        data_summary = self._prepare_data_summary(records)
        
        # 构建提示词
        prompt = self._build_analysis_prompt(data_summary, time_range)
        
        try:
            # 调用DeepSeek API
            response = self._call_deepseek_api(prompt)
            
            # 解析响应
            analysis_result = self._parse_analysis_response(response)
            
            return {
                "success": True,
                "error": None,
                "analysis": analysis_result.get("analysis", ""),
                "suggestions": analysis_result.get("suggestions", []),
                "time_distribution": data_summary.get("time_distribution", {}),
                "total_hours": data_summary.get("total_hours", 0),
                "record_count": data_summary.get("record_count", 0)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"AI分析失败: {str(e)}",
                "analysis": "",
                "suggestions": []
            }
    
    def _prepare_data_summary(self, records: List[Dict]) -> Dict:
        """
        准备数据摘要
        按活动类型和工作内容组合统计，保留详细的工作内容信息
        """
        if not records:
            return {
                "time_distribution": {},
                "total_hours": 0,
                "record_count": 0,
                "activity_details": []
            }
        
        # 按活动类型和工作内容组合统计
        activity_content_stats = {}
        total_minutes = 0
        
        for record in records:
            activity = record.get('activity_type', '其他')
            content = record.get('content', '').strip() if record.get('content') else '未填写'
            duration = record.get('duration_minutes', 0)
            
            # 使用"活动类型|工作内容"作为唯一key
            key = f"{activity}|{content}"
            
            if key not in activity_content_stats:
                activity_content_stats[key] = {
                    "activity_type": activity,
                    "work_content": content,
                    "total_minutes": 0,
                    "count": 0
                }
            
            activity_content_stats[key]["total_minutes"] += duration
            activity_content_stats[key]["count"] += 1
            total_minutes += duration
        
        # 计算百分比
        time_distribution = {}
        for key, stats in activity_content_stats.items():
            percentage = (stats["total_minutes"] / total_minutes * 100) if total_minutes > 0 else 0
            time_distribution[key] = {
                "activity_type": stats["activity_type"],
                "work_content": stats["work_content"],
                "hours": stats["total_minutes"] // 60,
                "minutes": stats["total_minutes"] % 60,
                "percentage": round(percentage, 1),
                "count": stats["count"]
            }
        
        # 准备活动详情（按活动类型分组，包含工作内容详情）
        activity_details = []
        
        # 先按活动类型分组
        activity_groups = {}
        for key, stats in activity_content_stats.items():
            activity = stats["activity_type"]
            if activity not in activity_groups:
                activity_groups[activity] = {
                    "total_minutes": 0,
                    "count": 0,
                    "work_contents": []
                }
            activity_groups[activity]["total_minutes"] += stats["total_minutes"]
            activity_groups[activity]["count"] += stats["count"]
            activity_groups[activity]["work_contents"].append({
                "content": stats["work_content"],
                "duration": stats["total_minutes"],
                "count": stats["count"]
            })
        
        # 生成活动详情
        for activity, stats in sorted(activity_groups.items(), 
                                     key=lambda x: x[1]["total_minutes"], 
                                     reverse=True):
            activity_details.append({
                "activity": activity,
                "hours": stats["total_minutes"] // 60,
                "minutes": stats["total_minutes"] % 60,
                "count": stats["count"],
                "work_contents": stats["work_contents"]  # 包含所有工作内容详情
            })
        
        return {
            "time_distribution": time_distribution,
            "total_hours": round(total_minutes / 60, 1),
            "record_count": len(records),
            "activity_details": activity_details
        }
    
    def _build_analysis_prompt(self, data_summary: Dict, time_range: str = None) -> str:
        """
        构建AI分析的提示词
        使用用户自定义的提示词模板
        """
        time_range_text = f"在{time_range}期间" if time_range else "在此期间"
        
        # 构建时间分配详情文本（按活动类型和工作内容组合）
        time_distribution_text = ""
        for key, stats in data_summary['time_distribution'].items():
            activity = stats['activity_type']
            content = stats['work_content']
            time_distribution_text += f"\n- 【{activity}】{content}: {stats['hours']}小时{stats['minutes']}分钟 ({stats['percentage']}%)，共{stats['count']}条记录"
        
        # 构建活动详情文本（包含详细的工作内容）
        activity_details_text = ""
        for detail in data_summary['activity_details']:
            activity_details_text += f"\n【{detail['activity']}】\n"
            activity_details_text += f"- 总时长: {detail['hours']}小时{detail['minutes']}分钟\n"
            activity_details_text += f"- 总记录数: {detail['count']}条\n"
            activity_details_text += f"- 具体工作内容:\n"
            for work in detail['work_contents']:
                work_hours = work['duration'] // 60
                work_minutes = work['duration'] % 60
                activity_details_text += f"  • {work['content']}: {work_hours}小时{work_minutes}分钟 ({work['count']}条记录)\n"
        
        # 使用模板格式化提示词
        try:
            prompt = self.user_prompt_template.format(
                time_range_text=time_range_text,
                record_count=data_summary['record_count'],
                total_hours=data_summary['total_hours'],
                time_distribution=time_distribution_text,
                activity_details=activity_details_text
            )
        except Exception as e:
            # 如果模板格式化失败，使用默认模板
            print(f"提示词模板格式化失败，使用默认模板: {e}")
            prompt = self.DEFAULT_USER_PROMPT_TEMPLATE.format(
                time_range_text=time_range_text,
                record_count=data_summary['record_count'],
                total_hours=data_summary['total_hours'],
                time_distribution=time_distribution_text,
                activity_details=activity_details_text
            )
        
        return prompt
    
    def _call_deepseek_api(self, prompt: str) -> str:
        """
        调用DeepSeek API，带重试机制
        """
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        data = {
            "model": "deepseek-reasoner",
            "messages": [
                {
                    "role": "system",
                    "content": self.system_prompt
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.7,
            "max_tokens": 2000
        }
        
        # 重试机制
        max_retries = 3
        timeout = 120  # 增加超时时间到120秒
        
        for attempt in range(max_retries):
            try:
                response = requests.post(
                    self.API_URL,
                    headers=headers,
                    json=data,
                    timeout=timeout
                )
                
                if response.status_code == 200:
                    return response.json()
                else:
                    raise Exception(f"API调用失败: {response.status_code} - {response.text}")
                    
            except requests.exceptions.Timeout:
                if attempt < max_retries - 1:
                    print(f"请求超时，正在进行第{attempt + 2}次重试...")
                    continue
                else:
                    raise Exception("API请求多次超时，请检查网络连接或稍后重试")
            except requests.exceptions.ConnectionError as e:
                if attempt < max_retries - 1:
                    print(f"连接错误，正在进行第{attempt + 2}次重试...")
                    continue
                else:
                    raise Exception(f"无法连接到API服务器: {str(e)}")
            except Exception as e:
                raise Exception(f"API调用失败: {str(e)}")
        
        raise Exception("API调用失败，已达到最大重试次数")
    
    def _parse_analysis_response(self, response: Dict) -> Dict:
        """
        解析AI分析响应
        """
        try:
            content = response['choices'][0]['message']['content']
            
            # 简单解析，提取分析和建议部分
            analysis = content
            suggestions = []
            
            # 尝试提取建议列表（查找数字编号或-符号开头的行）
            lines = content.split('\n')
            for line in lines:
                line = line.strip()
                # 匹配 "1. 建议内容" 或 "- 建议内容" 格式
                if (line.startswith(('1.', '2.', '3.', '4.', '5.', '- ')) and 
                    len(line) > 3 and 
                    not line.startswith(('1. ', '2. ', '3. ', '4. ', '5. ')) == False):
                    suggestion = line.lstrip('12345.- ').strip()
                    if suggestion and len(suggestion) > 10:
                        suggestions.append(suggestion)
            
            return {
                "analysis": analysis,
                "suggestions": suggestions[:5]  # 最多返回5条建议
            }
            
        except Exception as e:
            raise Exception(f"解析响应失败: {str(e)}")


# 测试代码
if __name__ == "__main__":
    # 测试数据
    test_records = [
        {
            "activity_type": "工作",
            "duration_minutes": 480,
            "content": "编写代码"
        },
        {
            "activity_type": "专业学习",
            "duration_minutes": 120,
            "content": "阅读技术文档"
        },
        {
            "activity_type": "娱乐",
            "duration_minutes": 90,
            "content": "看视频"
        }
    ]
    
    analyzer = TimeAnalyzer()
    result = analyzer.analyze_time_usage(test_records, "2024年3月")
    
    print("分析结果:")
    print(json.dumps(result, ensure_ascii=False, indent=2))
