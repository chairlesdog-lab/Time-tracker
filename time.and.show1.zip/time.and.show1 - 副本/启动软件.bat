@echo off
start /min cmd /c "python -m http.server 8080"
ping 127.0.0.1 -n 6 > nul
start http://localhost:8080/index.html
exit